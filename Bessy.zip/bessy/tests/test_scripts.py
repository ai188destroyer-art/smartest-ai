import json
from pathlib import Path
from types import SimpleNamespace
import unittest

from scripts.evaluate_models import score
from scripts.fetch_sources import check_repository, fetch
from tests.helpers import Case, reply_call
from bessy.models import Reply


class SourceFetcherTests(Case):
    def test_catalogue_has_unique_explicit_repositories(self):
        catalog = json.loads((Path(__file__).resolve().parents[1] / 'sources.json').read_text())
        projects = catalog['projects']
        self.assertEqual(len({p['id'] for p in projects}), len(projects))
        for project in projects:
            check_repository(project['repository'])
            self.assertTrue(project['license_note'])
            self.assertTrue(project['integration'])

    def test_non_github_protocols_and_shell_strings_rejected(self):
        for url in ['file:///x', 'git@github.com:x/y', 'https://evil.test/x.git', 'https://github.com/x/y.git;id', '-u']:
            with self.assertRaises(ValueError):
                check_repository(url)

    def test_fetch_records_exact_commit_without_executing_source(self):
        calls = []
        destination = self.root / 'upstreams'
        commit = 'a' * 40
        def runner(command, **kwargs):
            calls.append(command)
            if 'clone' in command:
                target = Path(command[-1])
                target.mkdir(parents=True)
                (target / 'LICENSE').write_text('fixture license')
            return SimpleNamespace(returncode=0, stdout=commit if 'rev-parse' in command else '')
        result = fetch({'id': 'sample', 'repository': 'https://github.com/org/repo.git'}, destination, runner=runner)
        self.assertEqual(result['commit'], commit)
        self.assertIn('LICENSE', result['license_file_hashes'])
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(command[0] == 'git' for command in calls))
        self.assertTrue(all('protocol.file.allow=never' in command for command in calls))

    def test_existing_source_is_preserved(self):
        destination = self.root / 'upstreams'
        (destination / 'sample').mkdir(parents=True)
        with self.assertRaises(ValueError):
            fetch({'id': 'sample', 'repository': 'https://github.com/org/repo.git'}, destination)


class EvaluationTests(unittest.TestCase):
    def test_exact_score(self):
        case = {'validator': 'exact', 'expected': '391'}
        self.assertTrue(score('391\n', case))
        self.assertFalse(score('The answer is 391', case))

    def test_json_types_are_not_interchangeable(self):
        case = {'validator': 'json_equal', 'expected': {'enabled': True}}
        self.assertTrue(score('{"enabled":true}', case))
        self.assertFalse(score('{"enabled":1}', case))
        self.assertFalse(score('{"enabled":NaN}', case))


class AdditionalRegressionTests(Case):
    def test_denied_action_is_not_requested_again(self):
        self.scripted([reply_call('write_file', {'path': 'no.txt', 'content': 'hello'}, 'a'),
                       reply_call('write_file', {'path': 'no.txt', 'content': 'hello'}, 'b'), Reply('stopped', [])])
        state = self.decide(self.start(), False)
        self.assertEqual(state['status'], 'completed')
        self.assertFalse((self.config.workspace / 'no.txt').exists())
        self.assertEqual(sum(e['kind'] == 'approval_requested' for e in self.store.events(state['id'])), 1)
