from dataclasses import replace
from pathlib import Path
import tempfile
import unittest

from bessy.config import Config, Model
from bessy.engine import Engine
from bessy.models import Reply, normalize_calls
from bessy.store import Store


def reply_call(name, arguments, identifier="call_test"):
    return Reply("", normalize_calls([{"id": identifier, "function": {"name": name, "arguments": arguments}}]))


class Scripted:
    def __init__(self, replies):
        self.replies = list(replies)
        self.requests = []

    def complete(self, alias, messages, tools):
        self.requests.append((alias, messages, tools))
        result = self.replies.pop(0)
        if isinstance(result, Exception):
            raise result
        return result


class Case(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = Config(self.root / "state", self.root / "workspace",
                             {"demo": Model("demo", "demo", "test")}, {"general": "demo"})
        self.store = Store(self.config.data_dir)
        self.engine = Engine(self.config, self.store)

    def scripted(self, replies, **config):
        self.config = replace(self.config, **config)
        self.provider = Scripted(replies)
        self.engine = Engine(self.config, self.store, self.provider)
        return self.engine

    def start(self, prompt="test task"):
        return self.engine.drive(self.engine.create(prompt)["id"])

    def decide(self, state, allow=True):
        a = state["queue"][0]
        self.engine.decide(state["id"], a["approval_id"], a["digest"], allow)
        return self.engine.drive(state["id"])
