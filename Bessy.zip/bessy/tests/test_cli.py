import json
from pathlib import Path
import subprocess
import sys

from tests.helpers import Case

ROOT = Path(__file__).resolve().parents[1]


class CLITests(Case):
    def setUp(self):
        super().setUp()
        self.config_path = self.root / 'cli.toml'
        self.config_path.write_text('[paths]\ndata="cli-state"\nworkspace="cli-workspace"\n[[models]]\nname="demo"\nprovider="demo"\nmodel="demo"\n[routes]\ngeneral="demo"\n')

    def cli(self, *arguments):
        return subprocess.run([sys.executable, '-m', 'bessy', '--config', str(self.config_path), *arguments],
                              cwd=ROOT, capture_output=True, text=True, timeout=5)

    def test_clean_cli_calculation(self):
        result = self.cli('run', '/calc 0.1+0.2', '--no-interactive')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('3/10', json.loads(result.stdout)['output'])

    def test_noninteractive_write_pauses_and_status_survives(self):
        result = self.cli('run', '/write pending.txt waiting', '--no-interactive')
        self.assertEqual(result.returncode, 2)
        data = json.loads(result.stdout)
        self.assertEqual(data['status'], 'waiting')
        self.assertFalse((self.root / 'cli-workspace' / 'pending.txt').exists())
        status = self.cli('status', data['id'])
        self.assertEqual(json.loads(status.stdout)['status'], 'waiting')
        cancel = self.cli('cancel', data['id'])
        self.assertEqual(json.loads(cancel.stdout)['status'], 'cancelled')

    def test_doctor_does_not_claim_live_connection(self):
        result = self.cli('doctor')
        self.assertEqual(result.returncode, 0)
        self.assertIn('not checked', json.loads(result.stdout)['model_connectivity'])

    def test_audit_after_cli_run(self):
        self.cli('run', '/calc 12*12', '--no-interactive')
        result = self.cli('verify-audit')
        self.assertEqual(result.returncode, 0)
        self.assertTrue(json.loads(result.stdout)['valid'])
