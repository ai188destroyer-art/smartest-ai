from dataclasses import replace
import threading
import time
from unittest.mock import patch

from bessy.engine import Engine
from bessy.errors import BessyError, Conflict, ProviderError
from bessy.models import Reply
from tests.helpers import Case, reply_call


class EngineTests(Case):
    def test_calculation_runs_without_permission(self):
        result = self.start("/calc 18*7+5")
        self.assertEqual(result["status"], "completed")
        self.assertIn('"exact":"131"', result["output"])

    def test_write_requires_exact_approval_then_happens_once(self):
        state = self.start("/write answer.txt hello")
        self.assertEqual(state["status"], "waiting")
        path = self.config.workspace / "answer.txt"
        self.assertFalse(path.exists())
        action = state["queue"][0].copy()
        state = self.decide(state)
        self.assertEqual(state["status"], "completed")
        self.assertEqual(path.read_text(), "hello")
        with self.assertRaises(Conflict):
            self.engine.decide(state["id"], action["approval_id"], action["digest"], True)
        self.engine.drive(state["id"])
        self.assertEqual(path.read_text(), "hello")

    def test_denial_has_no_effect(self):
        state = self.decide(self.start("/write denied.txt hello"), False)
        self.assertEqual(state["status"], "completed")
        self.assertFalse((self.config.workspace / "denied.txt").exists())
        self.assertIn("User denied", state["output"])

    def test_tampered_action_cannot_reuse_permission(self):
        state = self.start("/write okay.txt hello")
        a = state["queue"][0]
        a["arguments"]["path"] = "changed.txt"
        self.store.save(state, "tamper-test")
        with self.assertRaises(Conflict):
            self.engine.decide(state["id"], a["approval_id"], a["digest"], True)
        self.assertFalse((self.config.workspace / "changed.txt").exists())

    def test_wrong_run_approval_rejected(self):
        first, second = self.start("/write first.txt hi"), self.start("/write second.txt hi")
        a = first["queue"][0]
        with self.assertRaises(Conflict):
            self.engine.decide(second["id"], a["approval_id"], a["digest"], True)

    def test_expired_approval_rejected(self):
        state = self.start("/write expires.txt hi")
        a = state["queue"][0]
        with patch("bessy.engine.time.time", return_value=a["expires"] + 1):
            with self.assertRaises(Conflict):
                self.engine.decide(state["id"], a["approval_id"], a["digest"], True)

    def test_approval_expiring_in_queue_does_not_execute(self):
        state = self.start("/write expires.txt hi")
        a = state["queue"][0]
        self.engine.decide(state["id"], a["approval_id"], a["digest"], True)
        with patch("bessy.engine.time.time", return_value=a["expires"] + 1):
            result = self.engine.drive(state["id"])
        self.assertEqual(result["status"], "failed")
        self.assertFalse((self.config.workspace / "expires.txt").exists())

    def test_permission_decision_is_strict_boolean(self):
        state = self.start("/write x.txt hi")
        a = state["queue"][0]
        with self.assertRaises(BessyError):
            self.engine.decide(state["id"], a["approval_id"], a["digest"], "false")

    def test_all_calls_in_batch_get_separate_decisions(self):
        first = reply_call("write_file", {"path": "one.txt", "content": "1"}, "a")
        second = reply_call("write_file", {"path": "two.txt", "content": "2"}, "b")
        self.scripted([Reply("", first.calls + second.calls), Reply("done", [])])
        state = self.start()
        state = self.decide(state)
        self.assertEqual(state["status"], "waiting")
        self.assertTrue((self.config.workspace / "one.txt").exists())
        self.assertFalse((self.config.workspace / "two.txt").exists())
        state = self.decide(state, False)
        self.assertEqual(state["status"], "completed")
        tool_messages = [m for m in state["messages"] if m["role"] == "tool"]
        self.assertEqual([m["tool_call_id"] for m in tool_messages], ["a", "b"])

    def test_bad_tool_arguments_never_execute(self):
        for name, arguments in [("shell", {"command": "echo hi"}), ("write_file", {"path": "../x", "content": "bad"}),
                                ("write_file", {"path": "x", "content": "hi", "approved": True})]:
            self.scripted([reply_call(name, arguments), Reply("stopped", [])])
            result = self.start()
            self.assertEqual(result["status"], "completed")
            self.assertIn("error", result["messages"][-2]["content"])

    def test_model_budget_enforced(self):
        self.scripted([reply_call("calculate", {"expression": "1+2"})], max_calls=1)
        result = self.start()
        self.assertEqual(result["status"], "failed")
        self.assertEqual(len(self.provider.requests), 1)
        self.assertIn("budget", result["error"])

    def test_tool_budget_enforced_before_execution(self):
        a = reply_call("calculate", {"expression": "1"}, "a")
        b = reply_call("calculate", {"expression": "2"}, "b")
        self.scripted([Reply("", a.calls + b.calls)], max_tool_calls=1)
        result = self.start()
        self.assertEqual(result["status"], "failed")
        self.assertFalse(any(e["kind"] == "tool_started" for e in self.store.events(result["id"])))

    def test_context_limit_stops_before_network(self):
        self.scripted([], max_context_chars=100)
        self.assertEqual(self.start()["status"], "failed")
        self.assertEqual(self.provider.requests, [])

    def test_repeat_loop_detection(self):
        self.scripted([reply_call("calculate", {"expression": "2"}, "c" + str(i)) for i in range(5)])
        state = self.start()
        self.assertEqual(state["status"], "failed")
        self.assertIn("Repeated", state["error"])

    def test_provider_failure_is_saved(self):
        self.scripted([ProviderError("Server unavailable")])
        state = self.start()
        self.assertEqual(state["status"], "failed")
        self.assertEqual(self.store.get(state["id"])["error"], "Server unavailable")

    def test_truncated_tool_calls_never_run(self):
        r = reply_call("write_file", {"path": "truncated.txt", "content": "bad"})
        r.truncated = True
        self.scripted([r])
        state = self.start()
        self.assertEqual(state["status"], "incomplete")
        self.assertFalse((self.config.workspace / "truncated.txt").exists())

    def test_optional_review_and_revision(self):
        self.scripted([Reply("draft", []), Reply("Correct the date", []), Reply("revised", [])], reviewer="demo")
        state = self.engine.create("write", review=True)
        state = self.engine.drive(state["id"])
        self.assertEqual(state["output"], "revised")
        self.assertEqual(state["critique"], "Correct the date")
        self.assertEqual([len(r[2]) for r in self.provider.requests][1:], [0, 0])

    def test_saved_memory_searchable_in_new_run(self):
        state = self.start("/remember launch | Bessy launch checklist")
        self.decide(state)
        result = self.start("/search launch")
        self.assertIn("Bessy launch checklist", result["output"])

    def test_waiting_run_survives_restart(self):
        state = self.start("/write restart.txt hi")
        self.assertEqual(self.store.recover(), 0)
        self.engine = Engine(self.config, self.store)
        self.assertEqual(self.decide(self.store.get(state["id"]))["status"], "completed")

    def test_interrupted_effect_is_never_replayed(self):
        state = self.start("/write crash.txt hi")
        state["status"] = "working"
        self.store.save(state, "simulated_crash")
        self.assertEqual(self.store.recover(), 1)
        self.assertEqual(self.engine.drive(state["id"])["status"], "interrupted")
        self.assertFalse((self.config.workspace / "crash.txt").exists())

    def test_config_change_invalidates_pending_approval(self):
        state = self.start("/write config.txt hi")
        other = Engine(replace(self.config, max_calls=13), self.store)
        a = state["queue"][0]
        with self.assertRaises(BessyError):
            other.decide(state["id"], a["approval_id"], a["digest"], True)

    def test_cancel_waiting_run(self):
        state = self.start("/write stop.txt hi")
        self.engine.cancel(state["id"])
        self.assertEqual(self.engine.drive(state["id"])["status"], "cancelled")
        self.assertFalse((self.config.workspace / "stop.txt").exists())

    def test_cancel_inflight_model_blocks_subsequent_action(self):
        entered, release = threading.Event(), threading.Event()
        engine = self.engine
        class Blocking:
            def complete(self, *args):
                entered.set()
                release.wait(3)
                return reply_call("write_file", {"path": "cancelled.txt", "content": "bad"})
        engine.provider = Blocking()
        state = engine.create("task")
        t = threading.Thread(target=engine.drive, args=(state["id"],))
        t.start()
        self.assertTrue(entered.wait(2))
        engine.cancel(state["id"])
        release.set()
        t.join(3)
        self.assertFalse(t.is_alive())
        self.assertEqual(self.store.get(state["id"])["status"], "cancelled")
        self.assertFalse((self.config.workspace / "cancelled.txt").exists())

    def test_concurrent_drives_claim_run_only_once(self):
        self.scripted([Reply("only once", [])])
        run_id = self.engine.create("task")["id"]
        threads = [threading.Thread(target=self.engine.drive, args=(run_id,)) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(3)
        self.assertEqual(len(self.provider.requests), 1)
        self.assertEqual(self.store.get(run_id)["status"], "completed")
