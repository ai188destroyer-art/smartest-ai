from dataclasses import replace
from decimal import Decimal, localcontext
import os
from pathlib import Path
import random
import unittest

from bessy.calculator import calculate
from bessy.config import Config, Model, select_model, validate_endpoint
from bessy.errors import BessyError, Conflict
from bessy.jsonutil import loads
from bessy.store import ProcessLock, Store
from bessy.workspace import Workspace
from tests.helpers import Case


class CalculatorTests(unittest.TestCase):
    def test_exact_decimal_addition(self):
        self.assertEqual(calculate("0.1+0.2")["exact"], "3/10")

    def test_fraction_and_power(self):
        self.assertEqual(calculate("(2**10 + 4)/3")["exact"], "1028/3")
        self.assertEqual(calculate("2**-3")["exact"], "1/8")

    def test_unary_and_hex(self):
        self.assertEqual(calculate("-0x10 + +20")["exact"], "4")

    def test_independent_decimal_oracle(self):
        rng = random.Random(20261102)
        with localcontext() as ctx:
            ctx.prec = 60
            for _ in range(300):
                a, b, c, d = [rng.randint(-100000, 100000) for _ in range(4)]
                d = d or 1
                actual = Decimal(calculate(f"({a}*{b}+{c})/{d}")["decimal_28_digits"])
                expected = (Decimal(a) * Decimal(b) + Decimal(c)) / Decimal(d)
                self.assertLessEqual(abs(actual - expected), max(abs(expected), Decimal(1)) * Decimal("1e-27"))

    def test_malicious_or_unbounded(self):
        for expression in ["__import__('os').system('id')", "[0]*10", "True+1", "2**99999999", "1e999999999",
                           "(2**64)**64**64", "1/0", "lambda: 1", "(1).__class__", "2**0.5", "(" * 300 + "1" + ")" * 300]:
            with self.subTest(expression=expression), self.assertRaises(BessyError):
                calculate(expression)


class WorkspaceTests(Case):
    def test_text_roundtrip_and_no_overwrite(self):
        w = self.engine.tools.workspace
        w.write_new("hello.txt", "Bessy ✓")
        self.assertEqual(w.read("hello.txt"), "Bessy ✓")
        with self.assertRaises(BessyError):
            w.write_new("hello.txt", "overwrite")

    def test_bad_paths(self):
        for path in ["../secret", "/etc/passwd", ".env", "dir/../secret", "C:/file", "x\\y", "a//b", "CON.txt", "foo.", "a\x00b"]:
            with self.subTest(path=path), self.assertRaises(BessyError):
                self.engine.tools.workspace.path(path)

    @unittest.skipIf(os.name == "nt", "POSIX link creation test")
    def test_symlink_and_hardlink(self):
        outside = self.root / "outside.txt"
        outside.write_text("secret")
        linked = self.config.workspace / "link.txt"
        linked.symlink_to(outside)
        with self.assertRaises(BessyError):
            self.engine.tools.workspace.read("link.txt")
        os.link(outside, self.config.workspace / "hard.txt")
        with self.assertRaises(BessyError):
            self.engine.tools.workspace.read("hard.txt")

    @unittest.skipIf(os.name == "nt", "POSIX FIFO test")
    def test_special_file_rejected_without_blocking(self):
        os.mkfifo(self.config.workspace / "pipe")
        with self.assertRaises(BessyError):
            self.engine.tools.workspace.read("pipe")

    def test_large_and_binary_files_rejected(self):
        (self.config.workspace / "big.txt").write_bytes(b"a" * 64001)
        (self.config.workspace / "binary.txt").write_bytes(b"\xff\xfe")
        for name in ["big.txt", "binary.txt"]:
            with self.assertRaises(BessyError):
                self.engine.tools.workspace.read(name)

    def test_image_uses_signature(self):
        (self.config.workspace / "image.png").write_bytes(b"\x89PNG\r\n\x1a\nbody")
        self.assertTrue(self.engine.tools.workspace.image("image.png").startswith("data:image/png;base64,"))
        (self.config.workspace / "fake.png").write_bytes(b"<script>bad</script>")
        with self.assertRaises(BessyError):
            self.engine.tools.workspace.image("fake.png")


class StoreTests(Case):
    def test_memory_persistence_and_query_escaping(self):
        self.store.remember("Tennis plan", "Arlee practises tennis on Saturday", "run")
        other = Store(self.config.data_dir)
        self.assertEqual(other.search("tennis")[0]["title"], "Tennis plan")
        self.assertEqual(other.search('" OR 1=1; --')[0]["title"] if other.search('" OR 1=1; --') else "", "")
        self.assertEqual(other.search(""), [])

    def test_optimistic_revision_prevents_overwrite(self):
        original = self.engine.create("task")
        stale = self.store.get(original["id"])
        self.store.save(original, "test")
        with self.assertRaises(Conflict):
            self.store.save(stale, "stale")

    def test_audit_detects_edits(self):
        self.engine.create("task")
        self.assertTrue(self.store.verify_audit()["valid"])
        with self.store.connect() as db:
            db.execute("UPDATE audit SET kind='altered' WHERE seq=1")
        self.assertFalse(self.store.verify_audit()["valid"])

    def test_process_lock(self):
        with ProcessLock(self.config.data_dir):
            with self.assertRaises(BessyError):
                with ProcessLock(self.config.data_dir):
                    pass


class ConfigurationTests(Case):
    def test_example_configs_parse(self):
        root = Path(__file__).resolve().parents[1]
        for name in ["config.toml", "config.demo.toml", "config.example.remote.toml"]:
            self.assertTrue(Config.load(root / name).models)

    def test_bad_endpoints(self):
        for url in ["http://example.com/v1", "https://user:secret@example.com", "file:///etc/passwd", "https://x/?key=secret"]:
            with self.subTest(url=url), self.assertRaises(BessyError):
                validate_endpoint(url)
        validate_endpoint("http://127.0.0.1:8000/v1")
        validate_endpoint("https://example.com/v1")

    def test_route_and_override(self):
        config = replace(self.config, models={**self.config.models, "coder": Model("coder", "demo", "coder")},
                         routes={"general": "demo", "coding": "coder"})
        self.assertEqual(select_model(config, "debug this python code"), ("coder", "coding"))
        self.assertEqual(select_model(config, "debug this python code", "demo"), ("demo", "manual"))

    def test_vision_requires_capability(self):
        with self.assertRaises(BessyError):
            select_model(self.config, "what is this", has_image=True)

    def test_config_state_not_exposed_in_workspace(self):
        path = self.root / "bad.toml"
        path.write_text('[paths]\ndata="workspace/state"\nworkspace="workspace"\n[[models]]\nname="test"\nprovider="demo"\nmodel="test"\n[routes]\ngeneral="test"\n')
        with self.assertRaises(BessyError):
            Config.load(path)

    def test_strict_json(self):
        for raw in ['{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}']:
            with self.assertRaises(BessyError):
                loads(raw)
