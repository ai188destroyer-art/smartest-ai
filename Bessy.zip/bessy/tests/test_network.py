from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import socket
import threading
import unittest
from unittest.mock import patch

from bessy.config import Model
from bessy.errors import BessyError, ProviderError
from bessy.models import Providers, normalize_calls, ollama_messages
from bessy.net import fetch_text, post_json, resolve_public, validate_web_url
from bessy.sandbox import docker_command, run_python
from tests.helpers import Case


class ProviderContractTests(Case):
    def setUp(self):
        super().setUp()
        self.requests = []
        self.response = {"choices": [{"message": {"content": "hello", "role": "assistant"}, "finish_reason": "stop"}],
                         "usage": {"prompt_tokens": 12, "completion_tokens": 3}}
        self.status = 200
        test = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                raw = self.rfile.read(int(self.headers['Content-Length']))
                test.requests.append((self.path, dict(self.headers), json.loads(raw)))
                data = json.dumps(test.response).encode()
                self.send_response(test.status)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(data)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.close)
        self.url = 'http://127.0.0.1:' + str(self.server.server_address[1])

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)

    def provider(self, kind='openai', **kwargs):
        m = Model('live', kind, 'fixture-model', self.url + ('/v1' if kind == 'openai' else ''), **kwargs)
        return Providers(replace(self.config, models={'live': m}, routes={'general': 'live'}))

    def test_openai_wire_contract(self):
        p = self.provider(output_parameter='max_completion_tokens', api_key_env='BESSY_TEST_KEY')
        with patch.dict(os.environ, {'BESSY_TEST_KEY': 'fake-test-credential'}):
            reply = p.complete('live', [{'role': 'user', 'content': 'hi'}], self.engine.tools.available())
        path, headers, body = self.requests[0]
        self.assertEqual(path, '/v1/chat/completions')
        self.assertEqual(headers['Authorization'], 'Bearer fake-test-credential')
        self.assertEqual(body['max_completion_tokens'], 2048)
        self.assertNotIn('max_tokens', body)
        self.assertEqual(reply.content, 'hello')
        self.assertEqual(reply.input_tokens, 12)
        self.assertEqual(reply.output_tokens, 3)

    def test_ollama_wire_contract_and_usage(self):
        self.response = {'message': {'content': '', 'tool_calls': [{'function': {
            'name': 'calculate', 'arguments': {'expression': '2+2'}}}]}, 'prompt_eval_count': 7, 'eval_count': 9}
        reply = self.provider('ollama').complete('live', [{'role': 'user', 'content': 'calc'}], self.engine.tools.available())
        path, _, body = self.requests[0]
        self.assertEqual(path, '/api/chat')
        self.assertFalse(body['stream'])
        self.assertEqual(body['options']['num_predict'], 2048)
        self.assertEqual(reply.calls[0]['function']['arguments'], '{"expression":"2+2"}')
        self.assertEqual(reply.output_tokens, 9)

    def test_tool_result_and_image_conversion(self):
        messages = [{'role': 'user', 'content': [{'type': 'text', 'text': 'look'},
                    {'type': 'image_url', 'image_url': {'url': 'data:image/png;base64,YWJj'}}]},
                    {'role': 'tool', 'tool_call_id': 'a', 'name': 'calculate', 'content': '4'}]
        output = ollama_messages(messages)
        self.assertEqual(output[0]['images'], ['YWJj'])
        self.assertEqual(output[1]['tool_name'], 'calculate')
        self.assertNotIn('tool_call_id', output[1])
        self.assertIn('tool_call_id', messages[1])

    def test_failure_does_not_echo_sensitive_server_body(self):
        self.status, self.response = 401, {'error': 'a-secret-in-server-body'}
        with self.assertRaises(ProviderError) as context:
            self.provider().complete('live', [{'role': 'user', 'content': 'hello'}], [])
        self.assertNotIn('a-secret', str(context.exception))
        self.assertEqual(len(self.requests), 1)

    def test_no_hidden_retry_or_redirect(self):
        self.status = 302
        with self.assertRaises(ProviderError):
            post_json(self.url, '/redirect', {})
        self.assertEqual(len(self.requests), 1)

    def test_tools_disabled_rejects_provider_calls(self):
        self.response['choices'][0]['message']['tool_calls'] = [{'id': 'a', 'type': 'function',
            'function': {'name': 'calculate', 'arguments': '{"expression":"1"}'}}]
        with self.assertRaises(ProviderError):
            self.provider(tools=False).complete('live', [{'role': 'user', 'content': 'hello'}], [])

    def test_missing_key_fails_before_network(self):
        with patch.dict(os.environ, {}, clear=True), self.assertRaises(ProviderError):
            self.provider(api_key_env='BESSY_TEST_KEY').complete('live', [], [])
        self.assertEqual(self.requests, [])

    def test_invalid_response_structure(self):
        self.response = {'choices': []}
        with self.assertRaises(ProviderError):
            self.provider().complete('live', [], [])

    def test_thinking_budget_truncation_is_reported(self):
        self.response = {'message': {'content': ''}, 'done_reason': 'length'}
        reply = self.provider('ollama').complete('live', [], [])
        self.assertTrue(reply.truncated)


class NormalizationTests(unittest.TestCase):
    def test_duplicate_ids_and_json_rejected(self):
        for calls in [[{'id': 'a', 'function': {'name': 'calculate', 'arguments': '{}'}}] * 2,
                      [{'function': {'name': 'calculate', 'arguments': '{"x":1,"x":2}'}}],
                      [{'function': {'name': 'calculate', 'arguments': '[]'}}]]:
            with self.assertRaises(BessyError):
                normalize_calls(calls)

    def test_batch_limit(self):
        with self.assertRaises(ProviderError):
            normalize_calls([{}] * 9)


class NetworkPolicyTests(unittest.TestCase):
    def test_exact_host_and_https_only(self):
        for url in ['http://example.com', 'https://evil.example.com', 'https://example.com.evil.test',
                    'https://example.com@evil.test/', 'https://example.com:8080',
                    'https://example.com/#fragment', 'https://example.com/a\r\nb']:
            with self.subTest(url=url), self.assertRaises(BessyError):
                validate_web_url(url, ('example.com',))
        self.assertEqual(validate_web_url('https://example.com/a?b=c', ('example.com',)).hostname, 'example.com')

    def test_private_and_mixed_dns_blocked(self):
        def answer(ip):
            return (socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, 443))
        for addresses in [['127.0.0.1'], ['10.0.0.1'], ['169.254.169.254'], ['::1'], ['100.64.0.1'],
                          ['224.0.0.1'], ['8.8.8.8', '192.168.1.1']]:
            with patch('bessy.net.socket.getaddrinfo', return_value=[answer(i) for i in addresses]), self.assertRaises(BessyError):
                resolve_public('example.com')

    def test_public_resolution(self):
        answers = [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('8.8.8.8', 443))]
        with patch('bessy.net.socket.getaddrinfo', return_value=answers):
            self.assertEqual(resolve_public('example.com'), ['8.8.8.8'])

    def test_fetch_does_not_follow_redirect(self):
        with patch('bessy.net.resolve_public', return_value=['8.8.8.8']), patch('bessy.net.PinnedHTTPSConnection') as cls:
            cls.return_value.getresponse.return_value.status = 302
            with self.assertRaises(BessyError):
                fetch_text('https://example.com', ('example.com',))
            self.assertEqual(cls.call_count, 1)

    def test_dns_is_pinned_at_connect(self):
        from bessy.net import PinnedHTTPSConnection
        with patch('bessy.net.socket.create_connection') as connect, patch('bessy.net.ssl.create_default_context') as context:
            connection = PinnedHTTPSConnection('example.com', '8.8.8.8', 5)
            connection.connect()
            connect.assert_called_once_with(('8.8.8.8', 443), 5)
            context.return_value.wrap_socket.assert_called_once_with(connect.return_value, server_hostname='example.com')


class SandboxPolicyTests(unittest.TestCase):
    def test_docker_is_required_and_no_fallback(self):
        with self.assertRaises(BessyError):
            run_python('print(1)', '', 1)
        with patch('bessy.sandbox.shutil.which', return_value=None), self.assertRaises(BessyError):
            run_python('print(1)', 'python@sha256:' + 'a' * 64, 1)

    def test_container_has_no_network_mounts_or_privilege(self):
        command = docker_command('python@sha256:' + 'a' * 64, 'bessy-test')
        for value in ['--network=none', '--read-only', '--cap-drop=ALL', '--pids-limit=32', '--memory=128m',
                      '--security-opt=no-new-privileges:true', '--pull=never', '--user=65534:65534']:
            self.assertIn(value, command)
        self.assertNotIn('--privileged', command)
        self.assertFalse(any(x.startswith(('--volume', '--mount')) for x in command))
