import http.client
import json
import threading
import time

from bessy.server import make_server
from tests.helpers import Case


class HTTPTests(Case):
    def setUp(self):
        super().setUp()
        self.token = 't' * 40
        self.server = make_server(self.engine, self.token, 0)
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.close)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)

    def request(self, method, path, body=None, auth=True, headers=None):
        h = {'Authorization': 'Bearer ' + self.token} if auth else {}
        if headers:
            h.update(headers)
        if body is not None:
            h['Content-Type'] = 'application/json'
        c = http.client.HTTPConnection('127.0.0.1', self.port, timeout=3)
        c.request(method, path, body=json.dumps(body) if body is not None else None, headers=h)
        r = c.getresponse()
        data = r.read()
        result = (r.status, dict(r.getheaders()), json.loads(data) if r.getheader('Content-Type', '').startswith('application/json') else data)
        c.close()
        return result

    def wait_state(self, run_id, status):
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            result = self.request('GET', '/api/runs/' + run_id)[2]
            if result['status'] == status:
                return result
            time.sleep(.01)
        self.fail('Run did not reach ' + status + ': ' + str(result))

    def test_auth_required(self):
        self.assertEqual(self.request('GET', '/api/runs', auth=False)[0], 401)
        self.assertEqual(self.request('GET', '/api/runs', headers={'Authorization': 'Bearer wrong'})[0], 401)

    def test_host_origin_and_csrf_rejected(self):
        for headers in [{'Host': 'attacker.test'}, {'Origin': 'https://attacker.test'}, {'Sec-Fetch-Site': 'cross-site'}]:
            self.assertEqual(self.request('GET', '/api/runs', headers=headers)[0], 403)

    def test_static_has_csp_and_no_embedded_token(self):
        status, headers, body = self.request('GET', '/', auth=False)
        self.assertEqual(status, 200)
        self.assertIn("script-src 'self'", headers['Content-Security-Policy'])
        self.assertNotIn(self.token.encode(), body)
        self.assertEqual(headers['Cache-Control'], 'no-store')

    def test_calculation_end_to_end(self):
        status, _, result = self.request('POST', '/api/runs', {'prompt': '/calc 0.1+0.2'})
        self.assertEqual(status, 202)
        completed = self.wait_state(result['id'], 'completed')
        self.assertIn('3/10', completed['output'])

    def test_approval_end_to_end_and_replay(self):
        _, _, result = self.request('POST', '/api/runs', {'prompt': '/write web.txt From the UI'})
        waiting = self.wait_state(result['id'], 'waiting')
        self.assertFalse((self.config.workspace / 'web.txt').exists())
        action = waiting['approval']
        body = {'approval_id': action['approval_id'], 'digest': action['digest'], 'allow': True}
        self.assertEqual(self.request('POST', '/api/runs/' + result['id'] + '/approval', body)[0], 202)
        self.wait_state(result['id'], 'completed')
        self.assertEqual((self.config.workspace / 'web.txt').read_text(), 'From the UI')
        self.assertEqual(self.request('POST', '/api/runs/' + result['id'] + '/approval', body)[0], 409)

    def test_denial_via_http(self):
        _, _, result = self.request('POST', '/api/runs', {'prompt': '/write denied.txt No'})
        a = self.wait_state(result['id'], 'waiting')['approval']
        self.request('POST', '/api/runs/' + result['id'] + '/approval',
                     {'approval_id': a['approval_id'], 'digest': a['digest'], 'allow': False})
        self.wait_state(result['id'], 'completed')
        self.assertFalse((self.config.workspace / 'denied.txt').exists())

    def test_cancel_via_http(self):
        _, _, result = self.request('POST', '/api/runs', {'prompt': '/write cancel.txt No'})
        self.wait_state(result['id'], 'waiting')
        self.assertEqual(self.request('POST', '/api/runs/' + result['id'] + '/cancel', {})[2]['status'], 'cancelled')

    def test_schema_rejects_unknown_fields(self):
        status, _, _ = self.request('POST', '/api/runs', {'prompt': 'hi', 'approved': True})
        self.assertEqual(status, 400)

    def test_bool_review_is_strict(self):
        self.assertEqual(self.request('POST', '/api/runs', {'prompt': 'hi', 'review': 'false'})[0], 400)

    def test_nonstring_route_is_a_client_error(self):
        self.assertEqual(self.request('POST', '/api/runs', {'prompt': 'hi', 'route': []})[0], 400)

    def test_invalid_unicode_is_a_client_error(self):
        self.assertEqual(self.request('POST', '/api/runs', {'prompt': '\ud800'})[0], 400)

    def test_path_and_query_token_not_accepted(self):
        self.assertEqual(self.request('GET', '/api/runs?token=' + self.token, auth=False)[0], 400)
        self.assertEqual(self.request('GET', '/../../etc/passwd')[0], 404)

    def test_symmetric_unicode_prompt(self):
        _, _, result = self.request('POST', '/api/runs', {'prompt': '你好 Bessy ✓'})
        completed = self.wait_state(result['id'], 'completed')
        self.assertEqual(completed['prompt'], '你好 Bessy ✓')

    def test_config_does_not_include_keys(self):
        result = self.request('GET', '/api/config')[2]
        self.assertNotIn('api_key', json.dumps(result))

    def test_large_body_rejected(self):
        self.assertEqual(self.request('POST', '/api/runs', {'prompt': 'a' * 128001})[0], 400)
