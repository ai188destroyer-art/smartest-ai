# Bessy

**A runnable personal AI workspace that connects your models, remembers approved notes, and uses tools with your permission.**

Bessy is original orchestration software. It is **not a newly trained foundation model**, a merger of incompatible model weights, or a demonstrated improvement over every other AI. Its intelligence comes from the models you connect. The included source catalogue covers 24 public projects across language, code, vision, media, speech, science, robotics, retrieval, training, and evaluation. This is a representative catalogue, not all AI code in existence. Some repositories provide release information rather than full implementations; the catalogue identifies that distinction.

## Start on Windows

1. Install [Python 3.11 or newer](https://www.python.org/downloads/) and [Ollama](https://ollama.com/download) from their official sites.
2. Extract this archive, open PowerShell inside the `bessy` folder, and run:

```powershell
ollama pull qwen3:8b
py -m bessy doctor
py -m bessy serve
```

3. Open **http://127.0.0.1:8765**. Paste the workspace access token printed in your terminal into the panel. Keep the terminal open.
4. Give Bessy a task. For example: **“Calculate 18 × 7 + 5 using the calculator, then write the result into answer.txt.”** Review the exact action before approving the file creation.

The first command downloads model weights. The [official `qwen3:8b` page](https://ollama.com/library/qwen3:8b) listed a 5.2 GB download when reviewed on 2 November 2026; working memory and context require additional space. It is a practical starting model, not a claim about the current best model. For a smaller machine, choose another model you have tested and update `model` in `config.toml`.

On macOS/Linux, use `python3` instead of `py`. No third-party Python dependencies are needed for Bessy's core. SQLite must include FTS5, as the usual Python distributions do. Model serving is a separate installation. All commands below run from the extracted project folder.

## Try the controls without downloading a model

```powershell
py -m bessy --config config.demo.toml serve
```

The **demo is a deterministic test fixture, not a real AI**. Use `/calc (18*7)+5`, `/write hello.txt Hello from Bessy`, `/remember launch | Review the Bessy launch checklist`, or `/search launch`. This exercises the real permission, file, memory, persistence, and UI code without an API key or a model download.

## Implemented capabilities

| Capability | What actually works |
| --- | --- |
| Local models | Ollama native `/api/chat` adapter with tool calls |
| Hosted/local compatible servers | OpenAI-compatible Chat Completions adapter, configurable endpoint and model |
| Specialist routing | Explicit route or model override; transparent keyword defaults for general, coding, reasoning, writing, and vision |
| Vision | Explicit PNG/JPEG workspace attachment sent to a configured vision model; no image-generation tool |
| Agent execution | Bounded model/tool loop, multiple tool calls, persisted task state, restart-safe pending approvals |
| Mathematics | Bounded exact rational arithmetic with a 28-digit decimal representation; no `eval` |
| Memory | Owner-approved notes with provenance and SQLite FTS5/BM25 search; this is lexical retrieval, not model training |
| Files | Approved UTF-8 reads and new-file creation inside a dedicated workspace; never overwrites an existing file |
| Web evidence | Approved single-URL HTTPS text fetch on exact configured public hosts; no search engine or browser automation |
| Code execution | Optional networkless Docker Python runner; disabled until an image digest is configured |
| Answer review | Optional second model critique followed by a revision; extra model calls, not a guarantee of truth |
| Control panel | Local token-protected task history, approval/denial, cancellation, status, review, and audit events |
| Evaluation | Offline behavioral/security suite, arithmetic differential checks, protocol fixtures, and a live-model smoke runner |
| Public source collection | Catalogue and explicit source downloader with repository/commit/license-file hashes |

Image/video generation, speech synthesis/transcription, protein folding, robotics, model training, and vector databases are **catalogued extension candidates, not installed Bessy tools**. The source downloader does not connect or execute them. Bessy cannot operate arbitrary external accounts or physically act in the world just because text says “permission granted.”

## Add specialist models

Each `[[models]]` table gives a model an alias. Map task types to those aliases under `[routes]`. The model must already be available on the chosen serving endpoint. For example, to connect a coding model served by vLLM or llama.cpp, add this table **before** `[routes]`:

```toml
[[models]]
name = "coder"
provider = "openai"
model = "YOUR_SERVED_CODING_MODEL_ID"
base_url = "http://127.0.0.1:8000/v1"
tools = true
```

Then change `coding = "coder"` under `[routes]`. Set `tools = false` for a model/server without function calling. A capable model still needs the serving engine's correct chat template/tool parser. Model aliases take precedence over domain names when you explicitly select one.

For vision, configure `vision = true`, route `vision` to that alias, place an image in the dedicated `workspace` directory, and supply its relative path in the UI or with `--image photo.png`. The chosen model receives those pixels. The adapter validates a PNG/JPEG signature and size, not full image integrity; the model server owns decoding.

To enable optional answer review, set `reviewer = "REVIEW_MODEL_ALIAS"` at the **top** of the TOML file, before any table, and define that model. Select “Review answer” in the panel. Reviews cannot call tools. Using a different model can provide another perspective; it does not make its factual conclusions independently verified.

## Use an API key

Copy `config.example.remote.toml` to your own configuration, replace the model IDs, and set the referenced environment variable locally. Never put a real key into a prompt, source file, or saved note.

PowerShell (the key is entered without being displayed or stored in command history):

```powershell
$bessySecureKey = Read-Host "Model API key" -AsSecureString
$env:BESSY_MODEL_API_KEY = [System.Net.NetworkCredential]::new("", $bessySecureKey).Password
py -m bessy --config config.example.remote.toml serve
```

Remove the environment variable when finished: `Remove-Item Env:BESSY_MODEL_API_KEY`. For another compatible provider, edit the endpoint, model IDs, and token parameter. Remote endpoints require HTTPS. This adapter targets **Chat Completions**; Responses-only models and vendor-specific APIs require another adapter. Provider billing and model terms still apply. No account or credit is included.

## Permissions and boundaries

Calculation and approved-note retrieval run automatically within the task. **File reads, file creation, memory writes, web requests, and Python execution each require a separate exact-action approval.** Approvals are bound to run ID, tool, arguments, a random approval ID, a digest, and expiry. A permission in an answer or webpage cannot bypass this check. Denied exact actions are not re-requested within that run.

The workspace is created separately from the state directory. Keep it dedicated to Bessy, with no credentials or sensitive unrelated files. Make any subdirectories yourself. Hidden paths, path traversal, filesystem links, special files, and large files are rejected. There is no host shell tool, blanket “allow everything” setting, file-overwrite tool, self-modification, automatic code installation, or automatic training.

The panel binds only to loopback. **Do not expose it as a public or multi-user service.** It uses Python's local HTTP server, not a production web stack. See [docs/SECURITY.md](docs/SECURITY.md) for the threat model and residual limits. Tasks, tool results, images, and approved notes are stored locally in SQLite without encryption; protect the state directory and use disk encryption if appropriate.

## Enable controlled web fetching

In `[tools]`, set `allowed_web_hosts = ["docs.python.org"]` or another exact host you intend to allow. Each URL still requires approval. Requests use HTTPS/443, validate all resolved addresses, pin the actual connection to a checked public IP, verify TLS, and reject redirects. The URL, including its query, reaches the destination. Pages are untrusted evidence. Bessy is not a web crawler or a search engine.

## Enable optional Python execution

Install Docker and review its isolation on your host. Obtain a trusted Python image and its immutable repository digest, then place the full `repository@sha256:...` string in `[tools].docker_image`. For example:

```powershell
docker pull python:3.12-slim
docker image inspect python:3.12-slim --format '{{index .RepoDigests 0}}'
```

Copy the actual returned digest, not an invented value. Bessy uses `--pull=never`; the image must already exist locally. The runner has no network, host mounts, Docker socket mount, model credentials, or package installs. It has a read-only filesystem, non-root UID, dropped capabilities, CPU/memory/PID/output/time limits, and a small temporary filesystem. It returns stdout; there is no binary artifact export or live package installation. Use a dedicated VM for code you do not trust; containers share a kernel and are not a complete security boundary.

Docker execution was **not run in the build environment**, because no Docker engine was installed. The command construction and fail-closed behavior were tested. Run your own sandbox acceptance checks before enabling it.

## Collect public upstream code

```powershell
py scripts/fetch_sources.py --list
py scripts/fetch_sources.py qwen3 llama-cpp whisper --destination upstream-sources
```

To request every repository in the catalogue, use `--all` with a new destination. This may consume substantial bandwidth and disk. It downloads separate source checkouts, preserves their license files, and records exact Git commits in `source-lock.json`. It does not download separate model checkpoints, Git LFS objects, submodules, or full Git history, and does not install, execute, merge, or relicense the projects.

For repeatable retrieval, use `--from-lock upstream-sources/source-lock.json --destination sources-reproduced`. Review the locked commits before using their code. Repository availability, code licenses, model licenses, and data licenses are separate questions. Some public projects do not publish their full training stack or data. See [docs/PUBLIC_PROJECTS.md](docs/PUBLIC_PROJECTS.md).

## Test and measure improvements

```powershell
py scripts/verify.py
py -m bessy --config config.demo.toml run "/calc 0.1+0.2" --no-interactive
py -m bessy --config config.demo.toml verify-audit
```

For a configured real model:

```powershell
py scripts/evaluate_models.py --config config.toml --model local --output baseline.json
```

The shipped 12-case smoke dataset checks basic arithmetic, reading, code comprehension, and strict formatting. It is deliberately small and **cannot support claims of superior general intelligence**. Use held-out tasks representative of your work, compare quality, failures, latency, and cost, and only adopt changes that improve those results. The runner never executes model-generated code and never uses the demo to report a model quality score.

Optional browser tests: install the Node.js Playwright package and its Chromium browser, then run `node scripts/test_browser.cjs`. The test creates and removes a temporary demo workspace.

See [docs/VALIDATION.md](docs/VALIDATION.md) for the delivered results and untested boundaries. CI is included for Linux/Windows and Python 3.11–3.13; that matrix is a future execution configuration, not a claim that those jobs ran here.

## CLI and operations

```powershell
py -m bessy run "Explain this algorithm" --route coding
py -m bessy run "Review this image" --route vision --image photo.png
py -m bessy status
py -m bessy status RUN_ID
py -m bessy approve RUN_ID
py -m bessy cancel RUN_ID
```

Use the UI for these operations while the server is running; a second process cannot open the same state directory. `--no-interactive` stops at an approval and returns exit code 2. Completed CLI runs return 0; errors return 1 or an incomplete run returns 2. Each task has its own model conversation; use approved notes to carry facts between separate tasks. This version does not provide multi-turn chat across independent tasks.

An interrupted working task is marked `interrupted` on restart instead of replaying an uncertain side effect. Pending undecided approvals survive restart while unexpired and with unchanged configuration. Cancel stops subsequent steps; an already-started request/action may finish. Stop the server before backing up the whole state directory. Audit hashes detect edits relative to the stored chain; they do not protect against someone who can rewrite the entire database. Save the latest audit head externally if you need an external integrity anchor.

The original Bessy code is MIT licensed. Upstream projects retain their own terms. Architecture and the next evidence-driven improvements are in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
