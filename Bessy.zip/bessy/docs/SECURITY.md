# Bessy security model

This is a single-owner local application. It assumes the owner controls the configuration, state directory, workspace, operating system, model servers, and Docker daemon. It is not designed to isolate mutually hostile local users or tenants. Python's `http.server` documentation explicitly advises against production exposure: https://docs.python.org/3/library/http.server.html.

## Permission path

1. The provider returns proposed tool calls. The application parses strict JSON, rejects duplicate keys and non-finite numbers, normalizes IDs, validates names and fields, and enforces budgets.
2. An effectful or data-releasing action pauses the run. The owner sees the complete arguments, including code, text, filename, or URL.
3. Approval is matched against the pending run, random approval ID, exact action digest, state revision, configuration fingerprint, and deadline. It is not a reusable capability token and is never sent to the model.
4. The application records execution intent before dispatch. A crash cannot trigger an automatic repeat of an uncertain effect. An approved-but-not-started action also becomes interrupted after a process restart.
5. Each proposed action receives its own result. Denial, malformed arguments, and unavailable tools cannot become successful executions through model instructions.

Approvals are held in trusted application state. The internal Python dispatcher is not an authorization API and must not be exposed directly in extensions. Anyone with the UI token can create tasks and approve actions; protect that token like a local control credential.

## Implemented controls and remaining limits

| Area | Implemented | Remaining limit |
| --- | --- | --- |
| API | Loopback binding, bearer token, constant-time comparison, Host/Origin/Sec-Fetch-Site checks, no CORS grants, body bounds | No multi-user identity, public TLS termination, external rate-limit layer, or formal penetration test |
| Browser | Same-origin scripts/styles, CSP, frame denial, textContent rendering, token kept only in page memory | A malicious browser extension or compromised OS is outside this boundary |
| Files | Dedicated root, hidden/traversal/link restrictions, exclusive create, no overwrite, regular-file checks, size limits | Assumes no malicious same-user process racing ancestor directories; Windows filesystem behavior needs native verification |
| Model network | Owner-configured endpoints, HTTPS for remote hosts, environment keys, no redirects/proxies or automatic retry | Selected providers receive task text, attachments, evidence, and retrieved notes; provider retention/billing are external |
| Web tool | Exact host allowlist, explicit approval, HTTPS/443, public-IP checks, DNS-pinned TLS connection, response limits, no redirects | An allowed public host can receive data in the URL; approval must consider that. DNS resolution uses OS resolver behavior |
| Python | Disabled by default; pinned local image, no network or mounts, non-root, dropped caps, resource/time/output limits | Containers share host kernel; Docker availability, kernel isolation, and cleanup require real-environment validation |
| Memory | Explicit approval to save, source run provenance, bounded FTS retrieval | It is not an authority store; incorrect notes can persist. Notes/results are plaintext on disk |
| Cancellation | Persisted cancellation and revision checks prevent subsequent steps | In-flight approved actions can finish; a remote provider request may still be billed |
| Audit | SHA-256 chained events and externally visible head | Not immutable storage. Full-chain rewriting or tail removal cannot be detected without an external trusted anchor |
| Quality | Deterministic calculator, optional model review, tests, explicit model eval runner | Models can hallucinate; review is not an oracle. No universal accuracy or intelligence claim |
| Budgets | Model requests, tool requests, context characters, output tokens, deadlines, file/result sizes | No exact currency spending cap. Token use depends on provider behavior; billing cannot be inferred from call count |

No credential or sandbox token is included in model prompts. No API exists for the model to grant permissions, alter configuration, run a host shell, install plugins, execute downloaded repositories, or self-update. Adding capabilities requires owner-controlled source changes plus tests and review.

Webpages, files, notes, and tool results are untrusted content. The prompt tells the model this, but the actual permission boundary lives in application logic. Prompt injection can still influence a proposed answer or proposed action. Inspect the displayed arguments, especially network URLs and code.

Use a patched Python release and a dedicated non-admin OS account. Do not run the server as root. For untrusted code, prefer a disposable VM with no unrelated secrets and a rootless/container-isolated daemon where possible. Bessy does not mount a Docker socket into containers. Do not replace this with a host Python fallback.

If Docker cleanup reports uncertainty, inspect the returned container name and stop/remove it manually. Do not assume terminating the client process terminated the container. Reference: https://docs.docker.com/engine/containers/run/.

## Security regression targets

The suite exercises permission replay, different-run approvals, changed arguments, expired decisions, delayed execution, separate decisions within a batch, schema injection, denied-action repetition, concurrent workers, cancelled requests, interrupted tasks, unsafe paths, symlinks/hardlinks/FIFOs on POSIX, private/mixed DNS resolution, URL scheme/host restrictions, redirects, provider credential handling, HTTP authorization, cross-origin requests, and request size constraints.

Tests are evidence of those cases only. They are not a complete security audit or a guarantee that arbitrary code execution is safe.
