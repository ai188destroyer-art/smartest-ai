# Validation report

Release: **Bessy 0.1.0**. Review date: **2 November 2026**.

## Executed checks

| Check | Result | Scope |
| --- | --- | --- |
| Python behavioral/security suite | **89 tests passed** | Actual SQLite, filesystem, CLI processes, local HTTP server, concurrency, approvals, failures, persistence, provider protocol fixtures, source-fetch command contract, evaluation scoring |
| Arithmetic differential check | **300 seeded cases passed** within the test suite | Calculator output compared against a separate 60-digit Decimal computation; tolerance reflects the displayed 28-digit decimal |
| Python compilation | **Passed** | Core, scripts, and tests |
| JavaScript syntax | **Passed** | Control panel script and optional browser test |
| Source catalogue validation | **Passed** | 24 unique IDs, explicit public GitHub repository URLs, license notes, integration status |
| Python wheel build | **Passed** | Built without downloading runtime dependencies |
| Fresh virtual-environment installation | **Passed** | Installed built wheel with no package index or dependencies |
| Installed CLI smoke | **Passed** | Executed `(18*7)+5` through the actual engine/calculator, yielding exact `131` |
| Packaged UI assets | **Passed** | Confirmed HTML asset exists in installed package |

The executed runtime was **Linux with Python 3.12.14**. Tests of POSIX links/FIFOs apply to that host. Native Windows/macOS behavior and the CI matrix were not executed here. The workflow file defines future Linux/Windows checks, not completed runs.

The arithmetic test uses a fixed random seed so failures are reproducible. It is one test with 300 subcases, not 300 extra independent test functions. The provider tests send real HTTP requests to local fixture servers; they validate formats and behavior without pretending a fixture is a trained AI.

## Explicitly unverified

| Area | Status / reason |
| --- | --- |
| Real language model quality, tool choice, hallucination rate, latency | **Not tested.** No model weights or real model API credentials were supplied |
| Live Ollama, OpenAI, llama.cpp, vLLM, or specialist model compatibility | **Protocol-tested only.** Model/server-specific parser, reasoning, and context behavior still needs live verification |
| Vision inference | **Adapter/input checks only.** No real vision-model run |
| Docker sandbox execution/escape resistance/cleanup | **Policy and command checks only.** Docker is not installed in the build environment |
| Real public-web fetch and TLS path | **Policy and mocked transport checks only.** No full live fetch test through the application |
| Full browser workflow and visual layout | **Blocked.** The Playwright library was available but no Chromium binary was installed. Browser download attempts returned invalid/truncated archives. The included browser test did not reach page execution |
| Actual upstream Git downloads | **Not performed.** Repository pages were researched, and downloader behavior was tested with a controlled Git-command fixture; upstream code/weights are not bundled |
| Small live-model evaluation dataset | **Not run.** No fabricated model quality score is included |
| Public/multi-user deployment or formal security audit | **Not claimed.** This release is a single-owner local application |

Browser backend routes, static responses, CSP headers, authorization, approval, denial, cancellation, Unicode input, request size, and several injection paths were exercised over actual local HTTP. Those checks do not establish that browser rendering and interactions passed. Follow the README to run `scripts/test_browser.cjs` when Chromium is available.

## Improvements made during verification

- Preserved each tool-call/result relationship and required a separate decision for every sensitive action in a batch.
- Added exact-action digest, expiry, configuration fingerprint, and revision checks to prevent approval substitution and replay.
- Stopped uncertain crash recovery from replaying a possibly completed effect.
- Added cancellation checks around in-flight model calls and prevented duplicate concurrent claims.
- Prevented repeated requests for an exact action already denied in the same run.
- Rejected malformed, duplicate-key, non-finite, and invalid-Unicode inputs without executing them.
- Distinguished truncated model output from a complete response; partial tool calls are never executed.
- Corrected strict JSON evaluation so Boolean `true` is not accepted as numeric `1`.
- Made model reviews tool-free and recorded that they are fallible model opinions.
- Preserved original source licenses and made supported integrations versus catalogue-only candidates explicit.

## Reproduce

```text
python scripts/verify.py
node --check bessy/static/app.js
node --check scripts/test_browser.cjs
python -m pip wheel . --no-deps --no-build-isolation --no-index -w dist
```

The wheel build requires setuptools already installed; running Bessy directly from this source folder does not require pip. See `test-output.txt` for the executed test log. See `package-smoke.json` for the fresh-install result. No global “better than every other AI” or “no improvements remain” conclusion follows from these tests.
