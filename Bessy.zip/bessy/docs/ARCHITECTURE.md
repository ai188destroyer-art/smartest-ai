# Bessy architecture

Bessy combines capabilities at their interfaces. It does not concatenate unrelated repositories or average incompatible model parameters. One owner-controlled configuration maps tasks to served models. The core has no third-party Python runtime dependencies; heavy models live in separate processes.

```mermaid
flowchart TD
    User["Owner: CLI or local panel"] --> Engine["Persistent task engine"]
    Engine --> Router["Configured model route"]
    Router --> Ollama["Ollama endpoint"]
    Router --> Compatible["Compatible chat endpoint"]
    Engine --> Policy["Schema, budget, and permission checks"]
    Policy --> Approval["Owner approves exact action"]
    Approval --> Tools["File, web, memory, or container tool"]
    Policy --> Safe["Calculator or note search"]
    Tools --> State["SQLite state, notes, and audit"]
    Safe --> State
    State --> Engine
```

## Responsibilities

| Module | Responsibility |
| --- | --- |
| `config.py` | TOML parsing, endpoint validation, model capability declaration, explicit/keyword routing |
| `models.py` | Ollama and Chat Completions requests, message conversion, tool call normalization, usage reporting |
| `engine.py` | Bounded work loop, persisted states, approval checks, cancellation, optional review/revision |
| `store.py` | SQLite WAL transactions, optimistic revisions, approved notes, FTS5 retrieval, audit hashes, process lock |
| `tools.py` | Finite tool registry, argument schema validation, internal dispatch |
| `workspace.py` | Dedicated workspace path and file constraints, explicit image attachments |
| `calculator.py` | AST whitelist and bounded exact rational arithmetic |
| `net.py` | Trusted model transport and separately constrained public-web fetch |
| `sandbox.py` | Optional disposable Docker Python execution; no host fallback |
| `server.py` | Single-owner loopback API and bounded task queue (two workers, eight reserved slots) |
| `static/` | No-build local control panel with no external frontend assets |
| `scripts/` | Verification, source retrieval, optional browser checks, and live-model smoke evaluation |

## States and consistency

`ready` runs are atomically claimed as `working` through an optimistic revision update. Each model request is counted and saved before the network call. Tool calls are queued in provider order, with one result per call. A permission request changes the run to `waiting`; an owner decision changes it to `ready`. Finished runs become `completed`, `incomplete`, `failed`, or `cancelled`.

The global state-directory lock prevents competing Bessy processes. SQLite transactions plus revision checks prevent two worker threads from claiming the same state or overwriting a cancellation. An action's start is persisted before its side effect. Since a process can fail between a side effect and saving the result, the engine does not promise exactly-once external execution. It promises **no automatic replay after an uncertain interruption**. On restart, previously working or ready tasks become `interrupted` and require a new task; undecided waiting approvals remain reviewable until expiry.

The audit chain records model/tool events and action/result hashes. Full conversations remain in the run record. Truncating a model output does not execute partial tool calls. Context exhaustion stops rather than silently deleting the user's instructions or splitting tool/result pairs.

## How to make it measurably better

1. **Establish a real baseline.** Run a suitable model on your hardware and representative tasks. Record quality, latency, reported tokens, failures, and permission burden. The small shipped suite is only a setup check.
2. **Choose task specialists from results.** Evaluate a coding model, reasoning model, writer, and vision model separately. Configure routes only when evidence supports the change. Keyword routing is transparent but crude; a trained router would need held-out data and comparison against this baseline.
3. **Improve retrieval with measured relevance.** Add embeddings/reranking only after constructing a retrieval test set. Keep note provenance, deletion, stale-information handling, and permission semantics. Do not call hashing an embedding or claim memory changes model weights.
4. **Add media as isolated services.** Use exact model-specific adapters for images, video, audio, or scientific tools. Give each typed schemas, explicit grants, budgets, artifact handling, licenses, and real hardware tests. A repository in the catalogue is not an installed capability.
5. **Train only on curated data.** If fine-tuning becomes worthwhile, use reviewed examples, licensed data/base models, reproducible training settings, held-out evaluation, and rollback. PEFT/TRL are candidates, not completed training pipelines.
6. **Upgrade deployment when requirements change.** A public or team service needs a production application server, per-user authorization and data isolation, secret management, TLS, quotas, backups, operations monitoring, and an independent security review. This local application does not claim those properties.

The practical completion rule for this release is: implemented capabilities have reproducible checks, discovered defects are fixed, limitations are explicit, and the clean package starts from its instructions. “No meaningful improvement remains anywhere” is not a testable condition for an open-ended AI project. There are still valuable improvements that depend on hardware, actual model results, datasets, and intended tasks.
