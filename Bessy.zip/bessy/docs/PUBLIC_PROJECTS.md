# Public AI project catalogue

Reviewed from primary project pages on **2 November 2026**.

These are candidates for distinct jobs, not a ranked list of universal winners. A recent release, a benchmark result, an available repository, and a usable local model are different things. Select with task-specific evaluation and available hardware. No upstream code or weights are bundled in Bessy; the explicit downloader retrieves separate source trees.

The catalogue includes current large-model research such as GLM-5.3 and Kimi K3 alongside smaller practical starting models and established specialist libraries. Their results were not reproduced here. Some release repositories contain documentation and reports rather than full implementation or training code.

| Public project | Field | License evidence / qualification | Bessy status |
| --- | --- | --- | --- |
| [qwen3](https://github.com/QwenLM/Qwen3) | Language, writing, reasoning | Open weights: Apache-2.0 per official README. Inspect exact code and checkpoint licenses. | Model endpoint via Ollama or OpenAI-compatible serving; choose an actual model ID. |
| [deepseek-r1](https://github.com/deepseek-ai/DeepSeek-R1) | Reasoning and mathematics | MIT for main code and weights; distilled variants also have upstream model terms. | Chat endpoint supported. Tool support is model/server dependent; set tools=false if unsupported. |
| [qwen3-coder](https://github.com/QwenLM/Qwen3-Coder) | Code generation | Qwen3-Coder-30B-A3B-Instruct official model card declares Apache-2.0. Standalone GitHub repository LICENSE was not verified; review repository terms separately. | Route coding to a separately served compatible model. Not preinstalled. |
| [glm5](https://github.com/zai-org/GLM-5) | Current large-model coding and agent research | Repository identifies Apache-2.0; review exact GLM-5.x checkpoint terms separately. | Catalogue candidate. Official repository covers GLM-5.3 and related releases. Model-specific reasoning/tool parameters need live validation. |
| [kimi-k3](https://github.com/MoonshotAI/Kimi-K3) | Current large multimodal model research | Custom Kimi K3 License. Public availability is not a blanket MIT or Apache grant. | Release information and technical report, not a complete training implementation. Not a built-in integration; requires separate serving and compatibility work. |
| [qwen3-vl](https://github.com/QwenLM/Qwen3-VL) | Image understanding and OCR | Repository: Apache-2.0. Check exact checkpoint terms. | PNG/JPEG attachment adapters for compatible models; vision=true required. No live model test here. |
| [ollama](https://github.com/ollama/ollama) | Local model serving | MIT code; each downloaded model has its own terms. | Native /api/chat adapter implemented and protocol-tested. |
| [llama-cpp](https://github.com/ggml-org/llama.cpp) | CPU/GPU quantized inference | MIT code plus dependency notices; model weights separate. | Use OpenAI-compatible chat endpoint. Configure model and tool template on server. |
| [vllm](https://github.com/vllm-project/vllm) | GPU inference and batching | Apache-2.0 code; model weights separate. | Use OpenAI-compatible chat endpoint. Configure tool parser on server. |
| [diffusers](https://github.com/huggingface/diffusers) | Image/media generation | Apache-2.0 library; pipelines and model checkpoints can have different terms. | Catalogue only. No generation worker installed in Bessy. |
| [wan21](https://github.com/Wan-Video/Wan2.1) | Video generation | Official README identifies Apache-2.0 model licensing; retain exact files and notices. | Catalogue only. Requires a separate GPU pipeline. |
| [whisper](https://github.com/openai/whisper) | Speech recognition and transcription | MIT code and model weights per official README. | Catalogue only. Not connected to the task toolset. |
| [kokoro](https://github.com/hexgrad/kokoro) | Speech synthesis | Apache-2.0 repository; check voices and language dependencies separately. | Catalogue only. Requires separate audio inference setup. |
| [sam2](https://github.com/facebookresearch/sam2) | Image and video segmentation | Apache-2.0 with additional BSD-3-Clause component notices. | Catalogue only. No segmentation worker installed. |
| [sympy](https://github.com/sympy/sympy) | Symbolic mathematics | BSD-style license; preserve the repository LICENSE and notices. | Catalogue only. Bessy's built-in calculator implements bounded rational arithmetic, not symbolic algebra. |
| [scikit-learn](https://github.com/scikit-learn/scikit-learn) | Tabular prediction and classical ML | BSD-3-Clause library; data licenses separate. | Catalogue only. No automatic training or prediction pipeline installed. |
| [alphafold2](https://github.com/google-deepmind/alphafold) | Protein structure research | Apache-2.0 code; CC BY 4.0 parameters per official README. Databases and dependencies have their own terms. | Catalogue only. Research workflow, not a clinical tool. This is AlphaFold 2, not AlphaFold 3. |
| [lerobot](https://github.com/huggingface/lerobot) | Robotics learning | Apache-2.0 code; dataset/checkpoint licenses separate. | Catalogue only. Bessy has no physical robot control. |
| [sentence-transformers](https://github.com/huggingface/sentence-transformers) | Embeddings, retrieval, reranking | Apache-2.0 library; checkpoint licenses separate. | Catalogue only. Current Bessy memory uses SQLite FTS5/BM25 lexical search, not embeddings. |
| [qdrant](https://github.com/qdrant/qdrant) | Vector storage | Apache-2.0 code. | Catalogue only; SQLite is the implemented persistence layer. |
| [langgraph](https://github.com/langchain-ai/langgraph) | Stateful agent workflows | MIT library; hosted services have separate terms. | Catalogue only. Bessy uses its own bounded, persisted state machine. |
| [peft](https://github.com/huggingface/peft) | LoRA and efficient fine-tuning | Apache-2.0 library; training data and base model terms still apply. | Catalogue only. Bessy does not train weights or self-modify. |
| [trl](https://github.com/huggingface/trl) | Post-training and reinforcement learning | Apache-2.0 library; model and dataset terms separate. | Catalogue only. No continuous RL loop installed. |
| [lm-evaluation-harness](https://github.com/EleutherAI/lm-evaluation-harness) | Model evaluation | MIT library; benchmark datasets may use separate licenses. | Catalogue only. A smaller original smoke evaluation runner is included in Bessy. |

## Evidence and integration references

Repository links in the table are the primary sources for their descriptions and license indicators. Additional implementation references:

- [Ollama chat API](https://docs.ollama.com/api/chat): message, tool, and response shapes.
- [Ollama tool calling](https://docs.ollama.com/capabilities/tool-calling): multiple calls and corresponding results.
- [OpenAI Chat Completions reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create): function-call arguments, call IDs, token limits, usage, and finish reasons.
- [vLLM online serving](https://docs.vllm.ai/en/latest/serving/online_serving/): compatible serving interface.
- [llama.cpp server](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md): local serving documentation.
- [Qwen3-Coder-30B-A3B-Instruct model card](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct): checkpoint-specific license metadata and model/tool format notes.
- [Qwen3:8b distribution](https://ollama.com/library/qwen3:8b): practical default tag and download size.
- [Docker run reference](https://docs.docker.com/engine/containers/run/): execution flags and isolation controls.
- [Python HTTP server documentation](https://docs.python.org/3/library/http.server.html): local server capabilities and production-use warning.

## What “combine” means here

Bessy connects available models through defined request/response protocols and enforces permission around tools. It does not merge model weights, preserve unknown training data, copy proprietary systems, or inherit an upstream project's performance by listing its repository. Weights trained with different architectures/tokenizers cannot be made into a better model simply by concatenating source files.

The Bessy code is original and MIT licensed. Licenses in this catalogue are source indicators rather than a blanket redistribution clearance. Keep each upstream LICENSE/NOTICE and check the precise checkpoint, dataset, and dependency terms. Kimi K3 uses a custom license; the Qwen3-Coder repository and its named model card must be considered separately.

A complete acquisition of every public AI project is neither defined nor delivered. The downloader intentionally skips separate weight downloads, LFS blobs, submodules, and full history; preserve the generated source lock for reproducibility. It never executes the fetched code.
