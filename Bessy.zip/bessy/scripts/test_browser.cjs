// Optional development test: requires Node.js and the Playwright Chromium package.
// Uses a temporary demo workspace; never sends a prompt to a real model.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const {spawn} = require('node:child_process');
const {chromium} = require('playwright');

(async () => {
  const root = path.resolve(__dirname, '..');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bessy-browser-'));
  const config = path.join(tmp, 'test.toml');
  fs.writeFileSync(config, '[paths]\ndata="state"\nworkspace="workspace"\n[[models]]\nname="demo"\nprovider="demo"\nmodel="test"\n[routes]\ngeneral="demo"\n');
  const port = await new Promise(resolve => {
    const s = net.createServer().listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); });
  });
  const token = 'bessy-local-browser-test-token-0000000000';
  const child = spawn(process.env.BESSY_TEST_PYTHON || 'python', ['-m', 'bessy', '--config', config, 'serve', '--port', String(port)],
    {cwd: root, env: {...process.env, BESSY_UI_TOKEN: token}, stdio: ['ignore', 'pipe', 'pipe']});
  let browser;
  const checks = [];
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Server startup timeout')), 10000);
      child.stdout.on('data', d => { if (d.toString().includes('Bessy: http')) { clearTimeout(timer); resolve(); } });
      child.once('error', reject);
      child.once('exit', code => { if (code !== null) reject(new Error('Server exited: ' + code)); });
    });
    browser = await chromium.launch({headless: true, args: process.getuid && process.getuid() === 0 ? ['--no-sandbox'] : []});
    const page = await browser.newPage({viewport: {width: 1440, height: 1000}});
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(`http://127.0.0.1:${port}/`);
    await page.fill('#token', token);
    await page.click('#connect-form button');
    await page.waitForSelector('#workspace:not([hidden])');
    checks.push('Access-token unlock');
    await page.fill('#prompt', '/write browser.txt Approved by owner');
    await page.click('#submit-task');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'waiting');
    assert(!fs.existsSync(path.join(tmp, 'workspace', 'browser.txt')));
    assert((await page.textContent('#approval-body')).includes('Approved by owner'));
    checks.push('No write before approval');
    await page.click('#approve');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'completed');
    assert.equal(fs.readFileSync(path.join(tmp, 'workspace', 'browser.txt'), 'utf8'), 'Approved by owner');
    checks.push('Approved write completes');
    await page.click('#back');
    await page.fill('#prompt', '/write denied.txt Should never be created');
    await page.click('#submit-task');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'waiting');
    await page.click('#deny');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'completed');
    assert(!fs.existsSync(path.join(tmp, 'workspace', 'denied.txt')));
    checks.push('Denied write has no effect');
    await page.click('#back');
    await page.fill('#prompt', '/calc 0.1+0.2');
    await page.click('#submit-task');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'completed');
    assert((await page.textContent('#output')).includes('3/10'));
    checks.push('Exact calculation through browser');
    await page.click('#back');
    await page.fill('#prompt', '<img src=x onerror="window.bessyXss=true">');
    await page.click('#submit-task');
    await page.waitForFunction(() => document.querySelector('#run-status').textContent === 'completed');
    assert.equal(await page.evaluate(() => window.bessyXss), undefined);
    assert.equal(await page.locator('#run-title img').count(), 0);
    checks.push('Untrusted content is text, not HTML');
    await page.click('#back');
    if (process.env.BESSY_SCREENSHOT_DIR) {
      fs.mkdirSync(process.env.BESSY_SCREENSHOT_DIR, {recursive: true});
      await page.screenshot({path: path.join(process.env.BESSY_SCREENSHOT_DIR, 'desktop.png'), fullPage: true});
    }
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.locator('#submit-task').isVisible());
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    if (process.env.BESSY_SCREENSHOT_DIR) await page.screenshot({path: path.join(process.env.BESSY_SCREENSHOT_DIR, 'mobile.png'), fullPage: true});
    checks.push('Mobile layout has no horizontal overflow');
    await page.reload();
    await page.waitForSelector('#connect:not([hidden])');
    assert.equal(await page.inputValue('#token'), '');
    checks.push('Refresh clears access token');
    assert.deepEqual(errors, []);
    checks.push('No browser JavaScript errors');
    console.log(JSON.stringify({passed: checks.length, checks}, null, 2));
  } finally {
    if (browser) await browser.close();
    child.kill('SIGINT');
    await new Promise(resolve => { if (child.exitCode !== null) return resolve(); child.once('exit', resolve); setTimeout(() => { child.kill('SIGKILL'); resolve(); }, 3000); });
    fs.rmSync(tmp, {recursive: true, force: true});
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
