"""Run an explicit small model smoke evaluation. It is not a universal intelligence benchmark."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bessy.config import Config
from bessy.jsonutil import dumps, loads
from bessy.models import Providers


def score(answer, case):
    if case['validator'] == 'exact':
        return answer.strip() == case['expected']
    if case['validator'] == 'json_equal':
        try:
            return dumps(loads(answer)) == dumps(case['expected'])
        except Exception:
            return False
    raise ValueError('Unknown validator')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='config.toml')
    parser.add_argument('--model', required=True, help='Explicit model alias to test')
    parser.add_argument('--dataset', default=str(ROOT / 'evaluations' / 'smoke.jsonl'))
    parser.add_argument('--output', required=True, help='New JSON report path; never overwrites')
    args = parser.parse_args()
    config = Config.load(args.config)
    if args.model not in config.models:
        parser.error('Model alias is not configured')
    if config.models[args.model].provider == 'demo':
        parser.error('The deterministic demo is not a language model and cannot earn benchmark scores')
    output = Path(args.output)
    if output.exists():
        parser.error('Output already exists')
    raw = Path(args.dataset).read_bytes()
    cases = [loads(line) for line in raw.decode('utf-8').splitlines() if line.strip()]
    if not 1 <= len(cases) <= 1000:
        parser.error('Dataset must have 1–1000 cases')
    provider, results = Providers(config), []
    for case in cases:
        start = time.monotonic()
        try:
            response = provider.complete(args.model, [{'role': 'system', 'content': 'Follow the user instructions precisely.'},
                                                      {'role': 'user', 'content': case['prompt']}], [])
            row = {'id': case['id'], 'answer': response.content,
                   'passed': not response.truncated and score(response.content, case),
                   'reported_input_tokens': response.input_tokens, 'reported_output_tokens': response.output_tokens}
        except Exception as exc:
            from bessy.errors import BessyError
            row = {'id': case['id'], 'passed': False, 'error': str(exc) if isinstance(exc, BessyError) else 'Evaluation failed'}
        row['seconds'] = round(time.monotonic() - start, 4)
        results.append(row)
        print(case['id'] + ': ' + ('pass' if row['passed'] else 'fail'), flush=True)
    report = {'created_utc': datetime.now(timezone.utc).isoformat(), 'model_alias': args.model,
              'model_id': config.models[args.model].model, 'dataset_sha256': hashlib.sha256(raw).hexdigest(),
              'cases': len(results), 'passed': sum(r['passed'] for r in results),
              'median_seconds': statistics.median(r['seconds'] for r in results),
              'scope': 'Small smoke suite, tools disabled; not evidence of overall superiority.', 'results': results}
    with output.open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(str(output))
    return 0 if report['passed'] == report['cases'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
