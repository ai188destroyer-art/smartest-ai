"""Retrieve separate source checkouts. Does not install, run, merge, or relicense them."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def check_repository(url):
    if not isinstance(url, str) or not re.fullmatch(r"https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+\.git", url):
        raise ValueError("Only explicit public GitHub HTTPS repository URLs are accepted")
    return url


def run_git(arguments, hooks, env, runner=subprocess.run):
    command = ['git', '-c', 'core.hooksPath=' + str(hooks), '-c', 'protocol.file.allow=never',
               '-c', 'protocol.ext.allow=never', '-c', 'http.followRedirects=false',
               '-c', 'submodule.recurse=false', *arguments]
    result = runner(command, env=env, capture_output=True, text=True, timeout=600, check=False)
    if result.returncode:
        raise RuntimeError("Git operation failed; inspect connectivity and the incomplete target checkout")
    return result.stdout.strip()


def fetch(project, destination, revision=None, runner=subprocess.run):
    identifier = project['id']
    if not re.fullmatch(r"[a-z0-9-]+", identifier):
        raise ValueError("Invalid project identifier")
    url = check_repository(project['repository'])
    if revision and not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("Locked revision must be a full 40-character Git commit")
    destination = Path(destination)
    if destination.is_symlink():
        raise ValueError("Destination must not be a symbolic link")
    destination.mkdir(parents=True, exist_ok=True)
    target = destination.resolve() / identifier
    if target.exists() or target.is_symlink():
        raise ValueError("Target already exists; use a new destination directory")
    env = dict(os.environ, GIT_TERMINAL_PROMPT='0', GIT_CONFIG_NOSYSTEM='1',
               GIT_CONFIG_GLOBAL=os.devnull, GIT_LFS_SKIP_SMUDGE='1')
    with tempfile.TemporaryDirectory() as hooks:
        if revision:
            run_git(['init', str(target)], hooks, env, runner)
            run_git(['-C', str(target), 'remote', 'add', 'origin', url], hooks, env, runner)
            run_git(['-C', str(target), 'fetch', '--depth=1', 'origin', revision], hooks, env, runner)
            run_git(['-C', str(target), 'checkout', '--detach', 'FETCH_HEAD'], hooks, env, runner)
        else:
            run_git(['clone', '--depth=1', '--filter=blob:none', '--no-recurse-submodules', url, str(target)], hooks, env, runner)
        commit = run_git(['-C', str(target), 'rev-parse', 'HEAD'], hooks, env, runner)
    if not re.fullmatch(r"[0-9a-f]{40}", commit) or (revision and commit != revision):
        raise RuntimeError("Checkout commit does not match the requested revision")
    notices = {}
    for path in target.iterdir():
        if path.is_file() and not path.is_symlink() and path.name.upper().startswith(('LICENSE', 'COPYING', 'NOTICE')):
            notices[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'id': identifier, 'repository': url, 'commit': commit,
            'retrieved_utc': datetime.now(timezone.utc).isoformat(), 'license_file_hashes': notices,
            'weights_included': False, 'submodules_included': False, 'lfs_objects_included': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ids', nargs='*', help='Project IDs from sources.json')
    parser.add_argument('--all', action='store_true', help='Fetch all catalogue repositories; may use substantial bandwidth/disk')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--destination', default='upstream-sources')
    parser.add_argument('--from-lock', help='Fetch exact commits recorded by an earlier run into a new destination')
    args = parser.parse_args()
    catalog = json.loads((ROOT / 'sources.json').read_text())['projects']
    projects = {p['id']: p for p in catalog}
    if args.list or (not args.ids and not args.all and not args.from_lock):
        for p in catalog:
            print(f"{p['id']:24} {p['field']}\n  {p['repository']}\n  {p['integration']}")
        return 0
    locks = {}
    if args.from_lock:
        data = json.loads(Path(args.from_lock).read_text())
        locks = {p['id']: p for p in data['projects']}
    ids = list(projects) if args.all else (args.ids or list(locks))
    if len(ids) != len(set(ids)):
        parser.error('Duplicate project IDs')
    if any(i not in projects for i in ids):
        parser.error('Unknown project ID; use --list')
    if args.from_lock and any(i not in locks or locks[i]['repository'] != projects[i]['repository'] for i in ids):
        parser.error('Lock entries must match the reviewed repository catalogue')
    destination = Path(args.destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    lock_path = destination / 'source-lock.json'
    if lock_path.exists():
        parser.error('Destination has a source lock already; choose a new destination')
    results, failures = [], []
    for identifier in ids:
        try:
            print('Fetching ' + identifier, flush=True)
            results.append(fetch(projects[identifier], destination, locks.get(identifier, {}).get('commit')))
        except (ValueError, RuntimeError, OSError, subprocess.TimeoutExpired) as exc:
            failures.append({'id': identifier, 'error': str(exc)})
            print('Failed: ' + identifier + ' — ' + str(exc), file=sys.stderr)
    with lock_path.open('x', encoding='utf-8') as f:
        json.dump({'projects': results, 'failures': failures}, f, indent=2)
    print(str(lock_path))
    print('Source checkouts only. Review each license and dependency before integrating or executing anything.')
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
