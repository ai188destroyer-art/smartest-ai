"""Offline verification: compile Python and run the behavioral/security suite."""
import compileall
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
if not all(compileall.compile_dir(ROOT / folder, quiet=1) for folder in ('bessy', 'scripts', 'tests')):
    raise SystemExit(1)
raise SystemExit(subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], cwd=ROOT).returncode)
