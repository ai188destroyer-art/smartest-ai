from concurrent.futures import ThreadPoolExecutor
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import re
import threading
from urllib.parse import urlsplit

from . import __version__
from .errors import BessyError, Conflict
from .jsonutil import dumps, loads


class Busy(BessyError):
    pass


class Jobs:
    def __init__(self, engine):
        self.engine = engine
        self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="bessy")
        self.slots = threading.BoundedSemaphore(8)

    def reserve(self):
        if not self.slots.acquire(blocking=False):
            raise Busy("Task queue is full; wait for a running task to finish")

    def submit(self, run_id):
        def work():
            try:
                self.engine.drive(run_id)
            finally:
                self.slots.release()
        self.executor.submit(work)

    def close(self):
        self.executor.shutdown(wait=True, cancel_futures=False)


def make_server(engine, token, port=8765):
    if not isinstance(token, str) or len(token) < 32:
        raise BessyError("UI access token must be at least 32 characters")
    jobs = Jobs(engine)
    static = Path(__file__).parent / "static"
    assets = {"/": ("text/html; charset=utf-8", (static / "index.html").read_bytes()),
              "/app.js": ("text/javascript; charset=utf-8", (static / "app.js").read_bytes()),
              "/style.css": ("text/css; charset=utf-8", (static / "style.css").read_bytes())}

    class Handler(BaseHTTPRequestHandler):
        server_version = "Bessy"
        sys_version = ""

        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, *args):
            pass  # Never log URLs, prompts, tokens, or credentials by default.

        def send(self, code, value, content_type="application/json; charset=utf-8"):
            raw = value if isinstance(value, bytes) else dumps(value).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; "
                             "connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass
            self.close_connection = True

        def trusted_origin(self):
            port = self.server.server_address[1]
            hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            origins = {"http://" + h for h in hosts}
            if len(self.headers.get_all("Host", [])) != 1 or self.headers.get("Host") not in hosts:
                return False
            origin = self.headers.get("Origin")
            if origin and origin not in origins:
                return False
            return self.headers.get("Sec-Fetch-Site", "") != "cross-site"

        def authenticated(self):
            if len(self.headers.get_all("Authorization", [])) != 1:
                return False
            supplied = self.headers.get("Authorization", "")
            return hmac.compare_digest(supplied.encode("utf-8"), ("Bearer " + token).encode("utf-8"))

        def body(self):
            if self.headers.get("Transfer-Encoding") or len(self.headers.get_all("Content-Length", [])) != 1:
                raise BessyError("One Content-Length header is required; chunked requests are not accepted")
            if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
                raise BessyError("Use application/json")
            length_raw = self.headers["Content-Length"]
            if not re.fullmatch(r"[0-9]{1,7}", length_raw):
                raise BessyError("Invalid request length")
            length = int(length_raw)
            if not 1 <= length <= 128000:
                raise BessyError("Request body must be 1–128000 bytes")
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise BessyError("Incomplete request body")
            result = loads(raw)
            if not isinstance(result, dict):
                raise BessyError("Request must be a JSON object")
            return result

        def handle_request(self, method):
            if not self.trusted_origin():
                return self.send(403, {"error": "Untrusted Host or Origin"})
            if urlsplit(self.path).query or urlsplit(self.path).fragment:
                return self.send(400, {"error": "Query parameters are not supported"})
            path = self.path
            if method == "GET" and path in assets:
                kind, value = assets[path]
                return self.send(200, value, kind)
            if method == "GET" and path == "/health":
                return self.send(200, {"service": "bessy", "version": __version__})
            if not self.authenticated():
                return self.send(401, {"error": "Enter the access token printed in your terminal"})
            if method == "GET" and path == "/api/config":
                models = [{"alias": m.name, "model": m.model, "provider": m.provider, "vision": m.vision,
                           "endpoint": m.base_url if m.provider != "demo" else "offline demo"}
                          for m in engine.config.models.values()]
                return self.send(200, {"models": models, "routes": engine.config.routes,
                                       "review_available": bool(engine.config.reviewer), "max_calls": engine.config.max_calls})
            if method == "GET" and path == "/api/runs":
                fields = ("id", "status", "model", "prompt", "created")
                return self.send(200, {"runs": [{k: s[k] for k in fields} for s in engine.store.recent()]})
            if method == "POST" and path == "/api/runs":
                body = self.body()
                if set(body) - {"prompt", "route", "review", "image_path"} or "prompt" not in body:
                    raise BessyError("Unknown or missing run fields")
                jobs.reserve()
                try:
                    state = engine.create(**body)
                    jobs.submit(state["id"])
                except Exception:
                    jobs.slots.release()
                    raise
                return self.send(202, engine.view(state))
            match = re.fullmatch(r"/api/runs/([0-9a-f]{32})(/approval|/cancel)?", path)
            if match:
                run_id, operation = match.groups()
                if method == "GET" and not operation:
                    return self.send(200, engine.view(engine.store.get(run_id)))
                if method == "POST" and operation == "/cancel":
                    if self.body() != {}:
                        raise BessyError("Cancel body must be an empty object")
                    return self.send(200, engine.view(engine.cancel(run_id)))
                if method == "POST" and operation == "/approval":
                    body = self.body()
                    if set(body) != {"approval_id", "digest", "allow"}:
                        raise BessyError("Approval fields are approval_id, digest, and allow")
                    jobs.reserve()
                    try:
                        state = engine.decide(run_id, **body)
                        jobs.submit(run_id)
                    except Exception:
                        jobs.slots.release()
                        raise
                    return self.send(202, engine.view(state))
            return self.send(404, {"error": "Route not found"})

        def dispatch(self, method):
            try:
                self.handle_request(method)
            except Busy as exc:
                self.send(429, {"error": str(exc)})
            except Conflict as exc:
                self.send(409, {"error": str(exc)})
            except BessyError as exc:
                self.send(400, {"error": str(exc)})
            except (OSError, TimeoutError):
                self.send(408, {"error": "Request timed out or connection failed"})
            except Exception:
                self.send(500, {"error": "Internal error; inspect local state before retrying"})

        def do_GET(self):
            self.dispatch("GET")

        def do_POST(self):
            self.dispatch("POST")

    class LocalServer(ThreadingHTTPServer):
        daemon_threads = True
        request_queue_size = 16

        def server_close(self):
            # Shutdown stops queued steps; it does not grant permission to finish new work.
            for state in engine.store.recent(1000):
                if state["status"] in {"working", "ready"}:
                    try:
                        engine.cancel(state["id"])
                    except Conflict:
                        pass
            super().server_close()
            jobs.close()

    return LocalServer(("127.0.0.1", port), Handler)
