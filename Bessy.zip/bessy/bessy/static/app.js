'use strict';
const $ = id => document.getElementById(id);
let token = '', currentId = '', currentRun = null, poll = null;
const terminal = new Set(['completed', 'failed', 'cancelled', 'interrupted', 'incomplete']);
function notice(text = '') { $('notice').textContent = text; }
async function api(path, body) {
  const response = await fetch(path, {method: body === undefined ? 'GET' : 'POST',
    headers: {'Authorization': 'Bearer ' + token, ...(body === undefined ? {} : {'Content-Type': 'application/json'})},
    ...(body === undefined ? {} : {body: JSON.stringify(body)}), cache: 'no-store'});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed');
  return result;
}
function stopPolling() { if (poll) clearTimeout(poll); poll = null; }
function home() {
  stopPolling(); currentId = ''; currentRun = null;
  $('run-view').hidden = true; $('workspace').hidden = !token; $('connect').hidden = !!token;
  notice(); if (token) refreshHistory().catch(e => notice(e.message));
}
async function refreshHistory() {
  const sessionToken = token;
  const result = await api('/api/runs');
  if (!token || token !== sessionToken) return;
  $('history').replaceChildren();
  for (const run of result.runs) {
    const button = document.createElement('button'); button.className = 'history-item';
    button.textContent = run.prompt.slice(0, 70);
    const status = document.createElement('small'); status.textContent = run.status + ' · ' + run.model;
    button.append(status); button.addEventListener('click', () => showRun(run.id)); $('history').append(button);
  }
}
function render(run) {
  currentRun = run;
  $('run-title').textContent = run.prompt;
  $('run-status').textContent = run.status;
  $('metrics').textContent = `${run.model} · ${run.calls} model calls · ${run.tool_count} tool requests` +
    (run.usage_reported ? ` · ${run.input_tokens + run.output_tokens} reported tokens` : '');
  $('output').textContent = run.output || (run.status === 'waiting' ? 'Waiting for your decision.' : terminal.has(run.status) ? 'No final answer was produced.' : 'Working through your task…');
  $('run-error').textContent = run.error || '';
  $('approval').hidden = !run.approval;
  if (run.approval) {
    $('approval-title').textContent = run.approval.name;
    $('approval-body').textContent = JSON.stringify(run.approval.arguments, null, 2);
    $('approval-expiry').textContent = 'Expires ' + new Date(run.approval.expires * 1000).toLocaleTimeString() + ' · ' + run.approval.digest;
    $('approve').disabled = Date.now() > run.approval.expires * 1000;
    $('deny').disabled = $('approve').disabled;
  }
  $('review-details').hidden = !run.critique; $('critique').textContent = run.critique || '';
  $('events').replaceChildren();
  for (const event of run.events) {
    const div = document.createElement('div'); div.className = 'event';
    const label = document.createElement('div'); label.textContent = new Date(event.timestamp * 1000).toLocaleTimeString() + ' · ' + event.kind.replaceAll('_', ' ');
    const data = document.createElement('code'); data.textContent = JSON.stringify(event.payload);
    div.append(label, data); $('events').append(div);
  }
  $('cancel').hidden = terminal.has(run.status);
}
async function showRun(id) {
  stopPolling(); currentId = id; $('workspace').hidden = true; $('run-view').hidden = false; notice();
  async function update() {
    try {
      const run = await api('/api/runs/' + id);
      if (currentId !== id) return;
      render(run);
      if (!terminal.has(run.status)) poll = setTimeout(update, 1000);
      else refreshHistory().catch(e => notice(e.message));
    } catch (e) { notice(e.message); }
  }
  await update();
}
$('connect-form').addEventListener('submit', async event => {
  event.preventDefault(); token = $('token').value.trim();
  try {
    const config = await api('/api/config');
    $('token').value = ''; $('connection').textContent = 'Connected';
    $('route').replaceChildren(new Option('Choose automatically', 'auto'));
    for (const m of config.models) $('route').add(new Option(m.alias + ' · ' + m.model, m.alias));
    $('review').disabled = !config.review_available;
    $('review').checked = false;
    $('model-note').textContent = config.models.map(m => `${m.alias}: ${m.provider} / ${m.model} (${m.endpoint})`).join(' · ');
    home();
  } catch (e) { token = ''; notice(e.message); }
});
$('task-form').addEventListener('submit', async event => {
  event.preventDefault(); notice(); $('submit-task').disabled = true;
  try {
    const run = await api('/api/runs', {prompt: $('prompt').value, route: $('route').value,
      review: $('review').checked, image_path: $('image').value.trim()});
    await showRun(run.id);
  } catch (e) { notice(e.message); }
  finally { $('submit-task').disabled = false; }
});
async function decide(allow) {
  const run = currentRun, action = run && run.approval;
  if (!action) return;
  $('approve').disabled = $('deny').disabled = true;
  try {
    await api(`/api/runs/${run.id}/approval`, {approval_id: action.approval_id, digest: action.digest, allow});
    await showRun(run.id);
  } catch (e) { notice(e.message); $('approve').disabled = $('deny').disabled = false; }
}
$('approve').addEventListener('click', () => decide(true));
$('deny').addEventListener('click', () => decide(false));
$('cancel').addEventListener('click', async () => {
  try { const id = currentId; await api(`/api/runs/${id}/cancel`, {}); await showRun(id); }
  catch (e) { notice(e.message); }
});
$('new-task').addEventListener('click', home); $('back').addEventListener('click', home);
$('refresh').addEventListener('click', () => { if (token) refreshHistory().catch(e => notice(e.message)); });
$('disconnect').addEventListener('click', () => {
  token = ''; $('connection').textContent = 'Locked'; $('history').replaceChildren();
  for (const id of ['output','run-title','approval-body','approval-expiry','critique','run-error','metrics','model-note']) $(id).textContent = '';
  $('events').replaceChildren(); $('prompt').value = ''; $('image').value = ''; home();
});
