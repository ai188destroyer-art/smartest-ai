import argparse
import json
import os
import secrets
import shutil
import sys

from . import __version__
from .config import Config
from .engine import Engine
from .errors import BessyError
from .server import make_server
from .store import ProcessLock, Store


def display_action(action):
    print("\nPermission required for: " + action["name"])
    print(json.dumps(action["arguments"], ensure_ascii=True, indent=2))
    print("Action digest: " + action["digest"])


def finish(engine, state, interactive=True):
    state = engine.drive(state["id"])
    while state["status"] == "waiting" and interactive:
        action = state["queue"][0]
        display_action(action)
        try:
            allow = input("Approve exactly this action? [y/N] ").strip().lower() == "y"
        except EOFError:
            break
        engine.decide(state["id"], action["approval_id"], action["digest"], allow)
        state = engine.drive(state["id"])
    print(json.dumps(engine.view(state), ensure_ascii=True, indent=2))
    return 0 if state["status"] == "completed" else 2


def main(argv=None):
    parser = argparse.ArgumentParser(prog="bessy", description="Bessy — your local, permission-controlled AI workspace")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--config", default="config.toml")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run", help="Run one task, with exact-action approval prompts")
    run.add_argument("prompt")
    run.add_argument("--route", default="auto")
    run.add_argument("--review", action="store_true")
    run.add_argument("--image", default="", help="PNG/JPEG relative to workspace; sends it to the selected model")
    run.add_argument("--no-interactive", action="store_true", help="Pause at permission requests")
    serve = commands.add_parser("serve", help="Start the local browser control panel")
    serve.add_argument("--port", type=int, default=8765)
    status = commands.add_parser("status")
    status.add_argument("run_id", nargs="?")
    approve = commands.add_parser("approve", help="Review and decide a saved pending action")
    approve.add_argument("run_id")
    cancel = commands.add_parser("cancel")
    cancel.add_argument("run_id")
    commands.add_parser("doctor", help="Offline setup checks")
    commands.add_parser("verify-audit")
    args = parser.parse_args(argv)
    try:
        config = Config.load(args.config)
        with ProcessLock(config.data_dir):
            store = Store(config.data_dir)
            store.recover()
            engine = Engine(config, store)
            if args.command == "run":
                state = engine.create(args.prompt, args.route, args.review, args.image)
                return finish(engine, state, not args.no_interactive and sys.stdin.isatty())
            if args.command == "approve":
                state = store.get(args.run_id)
                if state["status"] != "waiting":
                    raise BessyError("Run has no pending approval")
                action = state["queue"][0]
                display_action(action)
                allow = input("Approve exactly this action? [y/N] ").strip().lower() == "y"
                engine.decide(state["id"], action["approval_id"], action["digest"], allow)
                return finish(engine, store.get(args.run_id), sys.stdin.isatty())
            if args.command == "cancel":
                print(json.dumps(engine.view(engine.cancel(args.run_id)), indent=2))
            elif args.command == "status":
                result = engine.view(store.get(args.run_id)) if args.run_id else [engine.view(s) for s in store.recent()]
                print(json.dumps(result, indent=2, ensure_ascii=True))
            elif args.command == "verify-audit":
                result = store.verify_audit()
                print(json.dumps(result, indent=2))
                return 0 if result["valid"] else 1
            elif args.command == "doctor":
                print(json.dumps({"version": __version__, "python": sys.version.split()[0], "sqlite_fts5": True,
                                  "models": [{"alias": m.name, "provider": m.provider, "model": m.model,
                                              "key_configured": bool(os.environ.get(m.api_key_env)) if m.api_key_env else None}
                                             for m in config.models.values()],
                                  "docker_installed": bool(shutil.which("docker")),
                                  "sandbox_enabled": bool(config.docker_image),
                                  "model_connectivity": "not checked; run a task to test the actual endpoint"}, indent=2))
            elif args.command == "serve":
                if not 1 <= args.port <= 65535:
                    raise BessyError("Port must be between 1 and 65535")
                token = os.environ.get("BESSY_UI_TOKEN") or secrets.token_urlsafe(32)
                server = make_server(engine, token, args.port)
                print(f"Bessy: http://127.0.0.1:{args.port}", flush=True)
                print("Access token (paste into the local panel): " + token, flush=True)
                print("Keep this terminal open. Press Ctrl+C to stop.", flush=True)
                try:
                    server.serve_forever(poll_interval=0.2)
                except KeyboardInterrupt:
                    pass
                finally:
                    server.server_close()
        return 0
    except (BessyError, EOFError) as exc:
        print("Bessy: " + (str(exc) or "Input ended"), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
