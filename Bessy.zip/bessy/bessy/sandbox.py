import shutil
import subprocess
import threading
import time
import uuid

from .errors import BessyError


def docker_command(image, name):
    return ["docker", "run", "--rm", "--pull=never", "--name", name,
            "--network=none", "--read-only", "--cap-drop=ALL",
            "--security-opt=no-new-privileges:true", "--pids-limit=32",
            "--memory=128m", "--memory-swap=128m", "--cpus=0.5",
            "--user=65534:65534", "--tmpfs=/tmp:rw,noexec,nosuid,size=16m",
            "--log-driver=none", "--interactive", image, "python", "-I", "-S", "-"]


def run_python(code, image, timeout):
    if not image:
        raise BessyError("Python sandbox is disabled; configure a reviewed image digest first")
    if not shutil.which("docker"):
        raise BessyError("Docker is required; host code execution is never used")
    name = "bessy-" + uuid.uuid4().hex
    try:
        proc = subprocess.Popen(docker_command(image, name), stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except OSError as exc:
        raise BessyError("Cannot start Docker sandbox") from exc
    chunks, finished, overflow = [], threading.Event(), threading.Event()

    def read_output():
        size = 0
        try:
            while True:
                chunk = proc.stdout.read1(4096)
                if not chunk:
                    break
                room = max(0, 64000 - size)
                chunks.append(chunk[:room])
                size += len(chunk)
                if size > 64000:
                    overflow.set()
                    break
        finally:
            finished.set()

    def write_input():
        try:
            proc.stdin.write(code.encode("utf-8"))
            proc.stdin.close()
        except (OSError, ValueError):
            pass

    reader = threading.Thread(target=read_output, daemon=True)
    writer = threading.Thread(target=write_input, daemon=True)
    reader.start()
    writer.start()
    deadline = time.monotonic() + timeout
    timed_out = False
    try:
        while proc.poll() is None:
            if overflow.is_set() or time.monotonic() >= deadline:
                timed_out = not overflow.is_set()
                proc.kill()
                break
            finished.wait(0.03)
            if finished.is_set() and proc.poll() is None:
                time.sleep(0.01)
        proc.wait(timeout=3)
    finally:
        if proc.poll() is None:
            proc.kill()
        # Killing the docker client alone does not reliably stop the container.
        try:
            cleanup = subprocess.run(["docker", "rm", "-f", name], stdout=subprocess.DEVNULL,
                                     stderr=subprocess.PIPE, timeout=5, check=False)
            cleanup_failed = cleanup.returncode != 0 and b"No such container" not in cleanup.stderr
        except (OSError, subprocess.TimeoutExpired):
            cleanup_failed = True
        reader.join(timeout=1)
        writer.join(timeout=1)
        if proc.stdout:
            proc.stdout.close()
    return {"stdout": b"".join(chunks).decode("utf-8", errors="replace"),
            "exit_code": proc.returncode, "timed_out": timed_out,
            "output_limit_exceeded": overflow.is_set(), "cleanup_may_have_failed": cleanup_failed,
            "container_name": name}
