from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import re
import sqlite3
import time
import uuid

from .errors import BessyError, Conflict
from .jsonutil import dumps, loads


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = self.directory / "bessy.sqlite3"
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY, revision INTEGER NOT NULL,
                    updated REAL NOT NULL, data TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL,
                    kind TEXT NOT NULL, timestamp REAL NOT NULL, payload TEXT NOT NULL,
                    previous TEXT NOT NULL, digest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT NOT NULL,
                    source TEXT NOT NULL, created REAL NOT NULL);
                CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
                    id UNINDEXED, title, content, tokenize='unicode61');
            """)
        try:
            self.path.chmod(0o600)
            self.directory.chmod(0o700)
        except OSError:
            pass  # Windows uses directory ACLs; see SECURITY.md.

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA synchronous=FULL")
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _audit(db, run_id, kind, payload):
        last = db.execute("SELECT digest FROM audit ORDER BY seq DESC LIMIT 1").fetchone()
        previous = last[0] if last else "0" * 64
        timestamp = time.time()
        serialized = dumps(payload)
        digest = hashlib.sha256(dumps([previous, run_id, kind, timestamp, serialized]).encode()).hexdigest()
        db.execute("INSERT INTO audit(run_id,kind,timestamp,payload,previous,digest) VALUES(?,?,?,?,?,?)",
                   (run_id, kind, timestamp, serialized, previous, digest))

    def create(self, state):
        state["revision"] = 0
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO runs VALUES(?,?,?,?)", (state["id"], 0, time.time(), dumps(state)))
            self._audit(db, state["id"], "created", {"model": state["model"], "domain": state["domain"]})
        return state

    def get(self, run_id):
        with self.connect() as db:
            row = db.execute("SELECT data FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            raise BessyError("Run not found")
        return loads(row[0])

    def save(self, state, kind, payload=None):
        revision = state["revision"]
        updated = dict(state, revision=revision + 1)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            cursor = db.execute("UPDATE runs SET revision=?,updated=?,data=? WHERE id=? AND revision=?",
                                (revision + 1, time.time(), dumps(updated), state["id"], revision))
            if cursor.rowcount != 1:
                raise Conflict("Run changed; refresh before acting")
            self._audit(db, state["id"], kind, payload or {})
        state["revision"] = revision + 1

    def recent(self, limit=40):
        with self.connect() as db:
            return [loads(r[0]) for r in db.execute("SELECT data FROM runs ORDER BY updated DESC LIMIT ?", (limit,))]

    def recover(self):
        # A process crash can occur after a side effect but before its result is saved.
        # Never replay that effect. A fresh run requires a fresh approval.
        with self.connect() as db:
            all_states = [loads(r[0]) for r in db.execute("SELECT data FROM runs")]
        count = 0
        for state in all_states:
            if state["status"] in {"working", "ready"}:
                state["status"] = "interrupted"
                state["error"] = "Process stopped before completion. Inspect prior effects; create a new run to continue."
                self.save(state, "recovered_as_interrupted")
                count += 1
        return count

    def events(self, run_id, limit=100):
        with self.connect() as db:
            rows = db.execute("SELECT seq,kind,timestamp,payload,digest FROM audit WHERE run_id=? ORDER BY seq DESC LIMIT ?",
                              (run_id, limit)).fetchall()
        return [dict(r, payload=loads(r["payload"])) for r in reversed(rows)]

    def verify_audit(self):
        previous, count = "0" * 64, 0
        with self.connect() as db:
            for row in db.execute("SELECT * FROM audit ORDER BY seq"):
                expected = hashlib.sha256(dumps([previous, row["run_id"], row["kind"], row["timestamp"], row["payload"]]).encode()).hexdigest()
                if row["previous"] != previous or row["digest"] != expected:
                    return {"valid": False, "failed_seq": row["seq"], "events": count}
                previous, count = expected, count + 1
        return {"valid": True, "events": count, "head": previous}

    def remember(self, title, content, source):
        mid = uuid.uuid4().hex
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO memories VALUES(?,?,?,?,?)", (mid, title, content, source, time.time()))
            db.execute("INSERT INTO memory_fts(id,title,content) VALUES(?,?,?)", (mid, title, content))
            self._audit(db, source, "memory_saved", {"id": mid, "sha256": hashlib.sha256(content.encode()).hexdigest()})
        return {"id": mid, "title": title}

    def search(self, query, limit=5):
        words = list(dict.fromkeys(re.findall(r"\w+", query, re.UNICODE)))[:20]
        if not words:
            return []
        expression = " OR ".join('"' + word + '"' for word in words)
        with self.connect() as db:
            rows = db.execute("""SELECT m.id,m.title,m.content,m.source,m.created,bm25(memory_fts) AS rank
                               FROM memory_fts JOIN memories m ON m.id=memory_fts.id
                               WHERE memory_fts MATCH ? ORDER BY rank LIMIT ?""", (expression, limit)).fetchall()
        return [dict(r, content=r["content"][:8000]) for r in rows]


class ProcessLock:
    """One Bessy CLI/server process per state directory, on POSIX and Windows."""
    def __init__(self, directory):
        self.directory = Path(directory)
        self.file = None

    def __enter__(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.file = open(self.directory / "process.lock", "a+b")
        try:
            if os.name == "nt":
                import msvcrt
                self.file.write(b"\0")
                self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.file.close()
            raise BessyError("Another Bessy process is using this state directory") from exc
        return self

    def __exit__(self, *args):
        if self.file:
            if os.name == "nt":
                import msvcrt
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            self.file.close()
