import http.client
from html.parser import HTMLParser
import ipaddress
import socket
import ssl
import time
from urllib.parse import urlsplit

from .errors import BessyError, ProviderError
from .jsonutil import dumps, loads


def post_json(base_url, path, body, key="", timeout=60):
    """Trusted, user-configured model endpoint. No redirects, proxies, or retries."""
    p = urlsplit(base_url.rstrip("/") + path)
    cls = http.client.HTTPSConnection if p.scheme == "https" else http.client.HTTPConnection
    connection = cls(p.hostname, p.port, timeout=timeout)
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Accept-Encoding": "identity"}
    if key:
        headers["Authorization"] = "Bearer " + key
    try:
        connection.request("POST", p.path, body=dumps(body).encode("utf-8"), headers=headers)
        response = connection.getresponse()
        if not 200 <= response.status < 300:
            # Don't echo server bodies: they may contain credentials or submitted data.
            raise ProviderError(f"Provider returned HTTP {response.status}; check model, credentials, and server logs")
        if response.getheader("Content-Encoding", "identity") not in {"identity", ""}:
            raise ProviderError("Compressed provider response not supported")
        raw = read_bounded(response, connection, 2_000_000, timeout)
        result = loads(raw)
        if not isinstance(result, dict):
            raise ProviderError("Provider response must be a JSON object")
        return result
    except BessyError:
        raise
    except (OSError, http.client.HTTPException, ValueError) as exc:
        raise ProviderError("Model request failed; check that your configured model server is running") from exc
    finally:
        connection.close()


def read_bounded(response, connection, limit, timeout):
    deadline = time.monotonic() + timeout
    chunks, size = [], 0
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise BessyError("Response time limit exceeded")
        if connection.sock:
            connection.sock.settimeout(remaining)
        chunk = response.read1(min(8192, limit + 1 - size))
        if not chunk:
            break
        chunks.append(chunk)
        size += len(chunk)
        if size > limit:
            raise BessyError("Response size limit exceeded")
    return b"".join(chunks)


def resolve_public(host):
    try:
        answers = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise BessyError("Web hostname resolution failed") from exc
    addresses = list(dict.fromkeys(item[4][0] for item in answers))
    if not addresses:
        raise BessyError("Web hostname has no addresses")
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if not ip.is_global or ip.is_multicast or ip.is_reserved or getattr(ip, "ipv4_mapped", None):
            raise BessyError("Private, reserved, and special network addresses are blocked")
    return addresses


def validate_web_url(url, allowed_hosts):
    try:
        p = urlsplit(url)
        port = p.port
    except ValueError as exc:
        raise BessyError("Invalid URL") from exc
    if len(url) > 2048 or any(ord(c) < 33 or ord(c) > 126 for c in url):
        raise BessyError("URL must be a short ASCII URL; percent-encode other characters")
    if p.scheme != "https" or not p.hostname or p.username or p.password or p.fragment or port not in {None, 443}:
        raise BessyError("Web tool allows only HTTPS on port 443 without credentials or fragments")
    if p.hostname not in allowed_hosts:
        raise BessyError("Web host is not in the exact configured allowlist")
    return p


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, address, timeout):
        super().__init__(host, 443, timeout=timeout)
        self.address = address

    def connect(self):
        sock = socket.create_connection((self.address, 443), self.timeout)
        try:
            self.sock = ssl.create_default_context().wrap_socket(sock, server_hostname=self.host)
        except BaseException:
            sock.close()
            raise


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.hidden = 0
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript"}:
            self.hidden += 1

    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript"}:
            self.hidden = max(0, self.hidden - 1)

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def fetch_text(url, allowed_hosts, timeout=15):
    p = validate_web_url(url, allowed_hosts)
    addresses = resolve_public(p.hostname)
    # Connect to a checked numeric IP while retaining the original TLS SNI/Host.
    connection = PinnedHTTPSConnection(p.hostname, addresses[0], timeout)
    try:
        target = (p.path or "/") + ("?" + p.query if p.query else "")
        connection.request("GET", target, headers={"User-Agent": "Bessy/0.1", "Accept-Encoding": "identity"})
        response = connection.getresponse()
        if response.status != 200:
            raise BessyError(f"Web request returned HTTP {response.status}; redirects are not followed")
        kind = response.getheader("Content-Type", "").split(";")[0].strip().lower()
        if kind not in {"text/plain", "text/html", "application/json"}:
            raise BessyError("Web tool accepts HTML, plain text, or JSON only")
        if response.getheader("Content-Encoding", "identity") not in {"identity", ""}:
            raise BessyError("Compressed web responses are not accepted")
        raw = read_bounded(response, connection, 512_000, timeout)
        content = raw.decode("utf-8", errors="replace")
        if kind == "text/html":
            parser = TextExtractor()
            parser.feed(content)
            content = " ".join(" ".join(parser.parts).split())
        return {"source_url": url, "untrusted_text": content[:24000], "truncated": len(content) > 24000}
    except BessyError:
        raise
    except (OSError, http.client.HTTPException) as exc:
        raise BessyError("Web fetch failed") from exc
    finally:
        connection.close()
