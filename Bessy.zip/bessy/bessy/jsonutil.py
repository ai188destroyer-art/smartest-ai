import json

from .errors import BessyError


def loads(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise BessyError("Duplicate JSON key")
            out[key] = value
        return out

    def constant(_):
        raise BessyError("Non-finite JSON number")

    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, RecursionError, UnicodeError) as exc:
        raise BessyError("Invalid JSON") from exc


def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
