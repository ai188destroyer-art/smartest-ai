from dataclasses import dataclass
from pathlib import Path
import ipaddress
import re
import tomllib
from urllib.parse import urlsplit

from .errors import BessyError


@dataclass(frozen=True)
class Model:
    name: str
    provider: str
    model: str
    base_url: str = "http://127.0.0.1:11434"
    api_key_env: str = ""
    tools: bool = True
    vision: bool = False
    output_parameter: str = "max_tokens"


@dataclass(frozen=True)
class Config:
    data_dir: Path
    workspace: Path
    models: dict[str, Model]
    routes: dict[str, str]
    reviewer: str = ""
    max_calls: int = 12
    max_tool_calls: int = 20
    max_output_tokens: int = 2048
    max_context_chars: int = 80000
    request_timeout: int = 60
    approval_ttl: int = 900
    allowed_web_hosts: tuple[str, ...] = ()
    docker_image: str = ""
    python_timeout: int = 10

    @classmethod
    def load(cls, path):
        path = Path(path).resolve()
        try:
            raw = tomllib.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise BessyError("Cannot read configuration; pass --config with a valid TOML file") from exc
        allowed = {"paths", "models", "routes", "limits", "tools", "reviewer"}
        if set(raw) - allowed:
            raise BessyError("Unknown top-level configuration field")
        models = {}
        for item in raw.get("models", []):
            try:
                m = Model(**item)
            except (TypeError, ValueError) as exc:
                raise BessyError("Invalid model configuration") from exc
            if not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", m.name) or m.name in models:
                raise BessyError("Model aliases must be unique simple names")
            if m.provider not in {"ollama", "openai", "demo"}:
                raise BessyError("Provider must be ollama, openai, or demo")
            if not isinstance(m.model, str) or not m.model or len(m.model) > 200:
                raise BessyError("Model ID must be a nonempty string")
            if type(m.tools) is not bool or type(m.vision) is not bool:
                raise BessyError("Model capability flags must be booleans")
            if m.output_parameter not in {"max_tokens", "max_completion_tokens"}:
                raise BessyError("Invalid output token parameter")
            if m.api_key_env and not re.fullmatch(r"[A-Z][A-Z0-9_]{0,80}", m.api_key_env):
                raise BessyError("API credentials must name an environment variable")
            if m.provider != "demo":
                validate_endpoint(m.base_url)
            models[m.name] = m
        routes = raw.get("routes", {})
        if not models or "general" not in routes:
            raise BessyError("Configure at least one model and a general route")
        if any(k not in {"general", "coding", "reasoning", "writing", "vision"} for k in routes):
            raise BessyError("Unknown route")
        if any(v not in models for v in routes.values()):
            raise BessyError("Every route must reference a configured model alias")
        reviewer = raw.get("reviewer", "")
        if reviewer and reviewer not in models:
            raise BessyError("Reviewer must reference a configured model")
        paths = raw.get("paths", {})
        if set(paths) - {"data", "workspace"}:
            raise BessyError("Unknown paths field")
        data = (path.parent / paths.get("data", ".bessy")).resolve()
        workspace = (path.parent / paths.get("workspace", "workspace")).resolve()
        if data == workspace or data in workspace.parents or workspace in data.parents:
            raise BessyError("State and workspace must be separate, non-nested directories")
        limits = raw.get("limits", {})
        bounds = {"max_calls": (1, 100), "max_tool_calls": (1, 100),
                  "max_output_tokens": (64, 32000), "max_context_chars": (1000, 500000),
                  "request_timeout": (1, 300), "approval_ttl": (1, 86400),
                  "python_timeout": (1, 30)}
        for key, value in limits.items():
            if key not in bounds or type(value) is not int or not bounds[key][0] <= value <= bounds[key][1]:
                raise BessyError("Invalid configured limit: " + key)
        tool_config = raw.get("tools", {})
        if set(tool_config) - {"allowed_web_hosts", "docker_image"}:
            raise BessyError("Unknown tools configuration field")
        hosts = tool_config.get("allowed_web_hosts", [])
        if not isinstance(hosts, list) or any(not isinstance(h, str) or not re.fullmatch(r"[a-z0-9.-]+", h) for h in hosts):
            raise BessyError("Web hosts must be an exact list of lowercase DNS names")
        docker_image = tool_config.get("docker_image", "")
        if docker_image and not re.fullmatch(r"[a-zA-Z0-9./:_-]+@sha256:[0-9a-f]{64}", docker_image):
            raise BessyError("Pin the sandbox image by its immutable sha256 digest")
        return cls(data, workspace, models, dict(routes), reviewer, **limits,
                   allowed_web_hosts=tuple(hosts), docker_image=docker_image)


def validate_endpoint(url):
    try:
        p = urlsplit(url)
        port = p.port
    except (ValueError, TypeError) as exc:
        raise BessyError("Invalid provider URL") from exc
    if p.scheme not in {"http", "https"} or not p.hostname or p.username or p.password or p.query or p.fragment:
        raise BessyError("Provider URL must be HTTP(S) without credentials, query, or fragment")
    try:
        loopback = ipaddress.ip_address(p.hostname).is_loopback
    except ValueError:
        loopback = p.hostname == "localhost"
    if p.scheme == "http" and not loopback:
        raise BessyError("Remote providers must use HTTPS")
    if port is not None and not 1 <= port <= 65535:
        raise BessyError("Invalid port")


def select_model(config, prompt, requested="auto", has_image=False):
    if not isinstance(requested, str) or len(requested) > 64:
        raise BessyError("Route must be a short model alias or route name")
    if requested in config.models:
        alias = requested
        domain = "manual"
    else:
        domain = requested
        if requested == "auto":
            text = prompt.lower()
            if has_image:
                domain = "vision"
            elif re.search(r"\b(code|python|javascript|typescript|debug|function|program|sql)\b", text):
                domain = "coding"
            elif re.search(r"\b(solve|calculate|proof|equation|math|reason)\b", text):
                domain = "reasoning"
            elif re.search(r"\b(story|novel|poem|write|rewrite|book)\b", text):
                domain = "writing"
            else:
                domain = "general"
        if domain not in {"general", "coding", "reasoning", "writing", "vision"}:
            raise BessyError("Unknown route or model alias")
        alias = config.routes.get(domain, config.routes["general"])
    if has_image and not config.models[alias].vision:
        raise BessyError("Select a model configured with vision=true before attaching an image")
    return alias, domain
