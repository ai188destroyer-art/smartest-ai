class BessyError(Exception):
    """A safe, user-facing error; never put credentials in this message."""


class Conflict(BessyError):
    pass


class ProviderError(BessyError):
    pass
