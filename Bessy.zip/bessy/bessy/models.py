from dataclasses import dataclass
import copy
import os
import re
import uuid

from .errors import BessyError, ProviderError
from .jsonutil import dumps, loads
from .net import post_json


@dataclass
class Reply:
    content: str
    calls: list
    input_tokens: int = 0
    output_tokens: int = 0
    usage_reported: bool = False
    truncated: bool = False

    def message(self):
        result = {"role": "assistant", "content": self.content}
        if self.calls:
            result["tool_calls"] = self.calls
        return result


def normalize_calls(calls):
    if calls is None:
        return []
    if not isinstance(calls, list) or len(calls) > 8:
        raise ProviderError("Provider returned too many or invalid tool calls")
    result, identifiers = [], set()
    for call in calls:
        if not isinstance(call, dict) or call.get("type", "function") != "function":
            raise ProviderError("Unsupported provider tool call type")
        f = call.get("function")
        if not isinstance(f, dict) or not isinstance(f.get("name"), str):
            raise ProviderError("Malformed provider tool call")
        identifier = call.get("id") or "call_" + uuid.uuid4().hex
        if not isinstance(identifier, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,128}", identifier) or identifier in identifiers:
            raise ProviderError("Duplicate or invalid tool call ID")
        identifiers.add(identifier)
        arguments = f.get("arguments")
        if isinstance(arguments, str):
            if len(arguments) > 100000:
                raise ProviderError("Tool arguments are too large")
            arguments = loads(arguments)
        if not isinstance(arguments, dict):
            raise ProviderError("Tool arguments must be a JSON object")
        result.append({"id": identifier, "type": "function", "function": {
            "name": f["name"], "arguments": dumps(arguments)}})
    return result


def ollama_messages(messages):
    result = copy.deepcopy(messages)
    for msg in result:
        msg.pop("tool_call_id", None)
        if msg.get("role") == "tool":
            msg["tool_name"] = msg.pop("name")
        content = msg.get("content")
        if isinstance(content, list):
            msg["content"] = "\n".join(item["text"] for item in content if item["type"] == "text")
            msg["images"] = [item["image_url"]["url"].split(",", 1)[1] for item in content if item["type"] == "image_url"]
        for call in msg.get("tool_calls", []):
            call.pop("id", None)
            call["function"]["arguments"] = loads(call["function"]["arguments"])
    return result


class Providers:
    def __init__(self, config):
        self.config = config

    def complete(self, alias, messages, tools):
        model = self.config.models[alias]
        if model.provider == "demo":
            return self.demo(messages, tools)
        key = os.environ.get(model.api_key_env, "") if model.api_key_env else ""
        if model.api_key_env and not key:
            raise ProviderError("Set the configured API key environment variable before starting Bessy")
        body = {"model": model.model, "messages": messages, "stream": False}
        if tools and model.tools:
            body["tools"] = tools
        if model.provider == "ollama":
            body["messages"] = ollama_messages(messages)
            body["options"] = {"num_predict": self.config.max_output_tokens}
            raw = post_json(model.base_url, "/api/chat", body, key, self.config.request_timeout)
            message = raw.get("message", {})
            usage = (raw.get("prompt_eval_count", 0), raw.get("eval_count", 0))
            reported = "eval_count" in raw
            truncated = raw.get("done_reason") == "length"
        else:
            # Canonical tool 'name' is useful locally; Chat Completions needs only the ID.
            body["messages"] = [{k: v for k, v in m.items() if not (m.get("role") == "tool" and k == "name")}
                                for m in messages]
            body[model.output_parameter] = self.config.max_output_tokens
            raw = post_json(model.base_url, "/chat/completions", body, key, self.config.request_timeout)
            choices = raw.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                raise ProviderError("Provider response has no chat choice")
            message = choices[0].get("message", {})
            usage_raw = raw.get("usage") or {}
            if not isinstance(usage_raw, dict):
                raise ProviderError("Invalid token usage metadata")
            usage = (usage_raw.get("prompt_tokens", 0), usage_raw.get("completion_tokens", 0))
            reported = bool(usage_raw)
            truncated = choices[0].get("finish_reason") == "length"
        if not isinstance(message, dict):
            raise ProviderError("Invalid assistant message")
        content = message.get("content") or message.get("refusal") or ""
        if not isinstance(content, str) or len(content) > 128000:
            raise ProviderError("Invalid or oversized assistant text")
        if any(type(n) is not int or n < 0 or n > 100_000_000 for n in usage):
            raise ProviderError("Invalid reported usage")
        calls = normalize_calls(message.get("tool_calls"))
        if calls and (not tools or not model.tools):
            raise ProviderError("Provider requested a tool when tools were disabled")
        if not content and not calls and not truncated:
            raise ProviderError("Provider returned an empty answer")
        return Reply(content, calls, *usage, reported, truncated)

    @staticmethod
    def demo(messages, tools):
        if messages[-1]["role"] == "tool":
            return Reply("DEMO — tool result:\n" + messages[-1]["content"], [])
        prompt = next(m["content"] for m in reversed(messages) if m["role"] == "user")
        if not isinstance(prompt, str):
            return Reply("DEMO does not interpret images.", [])
        name, arguments = "", {}
        if prompt.startswith("/calc "):
            name, arguments = "calculate", {"expression": prompt[6:]}
        elif prompt.startswith("/write "):
            parts = prompt[7:].split(" ", 1)
            if len(parts) == 2:
                name, arguments = "write_file", {"path": parts[0], "content": parts[1]}
        elif prompt.startswith("/remember ") and "|" in prompt:
            title, content = prompt[10:].split("|", 1)
            name, arguments = "remember", {"title": title.strip(), "content": content.strip()}
        else:
            commands = {"/read ": ("read_file", "path"), "/fetch ": ("web_fetch", "url"),
                        "/python ": ("python", "code"), "/search ": ("memory_search", "query")}
            for prefix, (tool, field) in commands.items():
                if prompt.startswith(prefix):
                    name, arguments = tool, {field: prompt[len(prefix):]}
                    break
        if name and tools:
            return Reply("DEMO — requesting " + name, normalize_calls([
                {"function": {"name": name, "arguments": arguments}}]))
        return Reply("DEMO — this is a deterministic setup test, not a language model. "
                     "Try /calc (18*7)+5 or /write hello.txt Hello. For real AI use config.toml with Ollama.", [])
