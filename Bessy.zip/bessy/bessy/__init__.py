"""Bessy: a local, permission-controlled model and tool orchestrator."""

__version__ = "0.1.0"
