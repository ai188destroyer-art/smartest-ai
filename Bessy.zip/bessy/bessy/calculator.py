import ast
from decimal import Decimal, localcontext
from fractions import Fraction

from .errors import BessyError


def calculate(expression):
    if not isinstance(expression, str) or not expression or len(expression) > 512:
        raise BessyError("Expression must contain 1–512 characters")
    try:
        tree = ast.parse(expression, mode="eval")
        if len(list(ast.walk(tree))) > 100:
            raise BessyError("Expression is too complex")

        def bounded(value):
            if value.numerator.bit_length() > 8192 or value.denominator.bit_length() > 8192:
                raise BessyError("Calculation exceeds the number size limit")
            return value

        def visit(node):
            if isinstance(node, ast.Constant) and type(node.value) in {int, float}:
                segment = ast.get_source_segment(expression, node)
                # Reject huge decimal exponents before Fraction allocates a large integer.
                import re
                match = re.search(r"[eE]([+-]?\d+)$", segment)
                if match and abs(int(match[1])) > 300:
                    raise BessyError("Decimal exponent exceeds limit")
                if segment.lower().startswith(("0x", "0b", "0o")):
                    return bounded(Fraction(node.value))
                return bounded(Fraction(segment.replace("_", "")))
            if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
                value = visit(node.operand)
                return value if isinstance(node.op, ast.UAdd) else -value
            if isinstance(node, ast.BinOp):
                a, b = visit(node.left), visit(node.right)
                if isinstance(node.op, ast.Add):
                    result = a + b
                elif isinstance(node.op, ast.Sub):
                    result = a - b
                elif isinstance(node.op, ast.Mult):
                    result = a * b
                elif isinstance(node.op, ast.Div):
                    result = a / b
                elif isinstance(node.op, ast.Mod):
                    result = a % b
                elif isinstance(node.op, ast.Pow):
                    if b.denominator != 1 or abs(b) > 64:
                        raise BessyError("Exponent must be an integer between -64 and 64")
                    if max(a.numerator.bit_length(), a.denominator.bit_length()) * abs(int(b)) > 8192:
                        raise BessyError("Power exceeds number size limit")
                    result = a ** int(b)
                else:
                    raise BessyError("Unsupported arithmetic operator")
                return bounded(result)
            raise BessyError("Only numbers, parentheses, +, -, *, /, %, and ** are allowed")

        answer = visit(tree.body)
        with localcontext() as ctx:
            ctx.prec = 28
            decimal = str(Decimal(answer.numerator) / Decimal(answer.denominator))
        return {"exact": str(answer), "decimal_28_digits": decimal}
    except BessyError:
        raise
    except (ValueError, SyntaxError, ArithmeticError, RecursionError) as exc:
        raise BessyError("Invalid or undefined arithmetic expression") from exc
