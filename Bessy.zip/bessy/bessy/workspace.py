import base64
import os
from pathlib import Path, PurePosixPath
import re
import stat

from .errors import BessyError


class Workspace:
    """Dedicated personal workspace; never mount a whole home directory here."""
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)

    def path(self, name):
        if not isinstance(name, str) or not name or len(name) > 240 or "\\" in name or ":" in name:
            raise BessyError("Use a short relative workspace path")
        p = PurePosixPath(name)
        if p.is_absolute() or any(x in {"", ".", ".."} or x.startswith(".") for x in name.split("/")):
            raise BessyError("Absolute, hidden, and parent paths are blocked")
        reserved = {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)], *[f"LPT{i}" for i in range(1, 10)]}
        for part in p.parts:
            if not re.fullmatch(r"[a-zA-Z0-9_ .-]+", part) or part.endswith((" ", ".")) or part.split(".")[0].upper() in reserved:
                raise BessyError("Unsupported workspace filename")
        candidate = self.root
        for part in p.parts:
            candidate = candidate / part
            if candidate.is_symlink() or (hasattr(candidate, "is_junction") and candidate.is_junction()):
                raise BessyError("Workspace links are blocked")
        if not candidate.resolve().is_relative_to(self.root):
            raise BessyError("Path escapes workspace")
        return candidate

    def read_bytes(self, name, limit=64000):
        path = self.path(name)
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0)
        try:
            fd = os.open(path, flags)
            with os.fdopen(fd, "rb") as f:
                info = os.fstat(f.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > limit:
                    raise BessyError("File must be a single-link regular file within the size limit")
                result = f.read(limit + 1)
                if len(result) > limit:
                    raise BessyError("File size limit exceeded")
                return result
        except OSError as exc:
            raise BessyError("Cannot read workspace file") from exc

    def read(self, name):
        try:
            return self.read_bytes(name).decode("utf-8")
        except UnicodeError as exc:
            raise BessyError("File is not UTF-8 text") from exc

    def write_new(self, name, content):
        path = self.path(name)
        raw = content.encode("utf-8")
        if len(raw) > 64000:
            raise BessyError("Write exceeds 64 KB")
        # Parents are owner-created to keep the write operation small and reviewable.
        if not path.parent.is_dir():
            raise BessyError("Parent directory must already exist in the workspace")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
        try:
            fd = os.open(path, flags, 0o600)
            with os.fdopen(fd, "wb") as f:
                f.write(raw)
                f.flush()
                os.fsync(f.fileno())
        except FileExistsError as exc:
            raise BessyError("File already exists; choose a new filename") from exc
        except OSError as exc:
            raise BessyError("Workspace write failed; inspect the target before retrying") from exc
        return {"path": name, "bytes": len(raw)}

    def image(self, name):
        raw = self.read_bytes(name, 5_000_000)
        if raw.startswith(b"\x89PNG\r\n\x1a\n"):
            mime = "image/png"
        elif raw.startswith(b"\xff\xd8\xff"):
            mime = "image/jpeg"
        else:
            raise BessyError("Only PNG and JPEG image attachments are supported")
        return "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")
